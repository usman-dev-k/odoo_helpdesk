{
    "name": "Helpdesk Portal Extended",
    "summary": """
        Helpdesk""",
    "version": "13.0.1.1.0",
    "license": "AGPL-3",
    "category": " ",
    "author": " "
    "C2i Change 2 Improve, "
    "Domatix, "
    "Factor Libre, "
    "SDi Soluciones, "
    "Odoo Community Association (OCA)",
    "website": "https://github.com/OCA/helpdesk",
    "depends": ["base","portal","helpdesk_mgmt"],
    "data": [
        "views/helpdesk_security_edit.xml",
        "views/res_users_view.xml",
        "views/helpdesk_portal_template.xml",
    ],
    # "demo": ["demo/helpdesk_demo.xml"],
    "development_status": "Beta",
    "application": True,
    "installable": True,
}
