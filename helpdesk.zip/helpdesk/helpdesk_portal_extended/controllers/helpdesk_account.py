from odoo.addons.helpdesk_mgmt.controllers.myaccount import CustomerPortalHelpdesk
from odoo.addons.portal.controllers.portal import pager as portal_pager
from odoo import _, http
from odoo.http import request
from odoo.osv.expression import OR


class CustomerPortalHelpDeskExt(CustomerPortalHelpdesk):
    def _prepare_portal_layout_values(self):
        values = super()._prepare_portal_layout_values()
        team = request.env.user.helpdesk_team_id
        ticket_count = request.env["helpdesk.ticket"].search_count(
            [("team_id", "=", team.id),("team_id", "!=", False)]
        )
        values["ticket_count"] = ticket_count
        return values

    @http.route(["/my/tickets", "/my/tickets/page/<int:page>"], type="http", auth="user", website=True, )
    def portal_my_tickets(self, page=1, date_begin=None, date_end=None, sortby=None, search=None, search_in='content',
                          filterby=None, **kw):
        values = self._prepare_portal_layout_values()
        team = request.env.user.helpdesk_team_id
        HelpdesTicket = request.env["helpdesk.ticket"]
        partner = request.env.user.partner_id
        # domain = [("partner_id", "child_of", partner.id)]
        domain = [("team_id", "=", team.id), ("team_id", "!=", False)]

        searchbar_sortings = {
            "date": {"label": _("Newest"), "order": "create_date desc"},
            "name": {"label": _("Name"), "order": "name"},
            "stage": {"label": _("Stage"), "order": "stage_id"},
            "update": {
                "label": _("Last Stage Update"),
                "order": "last_stage_update desc",
            },
        }
        searchbar_filters = {"all": {"label": _("All"), "domain": []}}
        searchbar_inputs = {
            'content': {'input': 'content', 'label': _('Search <span class="nolabel"> (in Content)</span>')},
        }

        for stage in request.env["helpdesk.ticket.stage"].search([]):
            searchbar_filters.update(
                {
                    str(stage.id): {
                        "label": stage.name,
                        "domain": [("stage_id", "=", stage.id)],
                    }
                }
            )
        # default sort by order
        if not sortby:
            sortby = "date"
        order = searchbar_sortings[sortby]["order"]

        # default filter by value
        if not filterby:
            filterby = "all"
        domain += searchbar_filters[filterby]["domain"]

        if search and search_in:
            search_domain = []
            if search_in in ('content', 'all'):
                search_domain = OR([search_domain, ['|', ('name', 'ilike', search), ('number', 'ilike', search)]])
            domain += search_domain

        # count for pager
        ticket_count = HelpdesTicket.sudo().search_count(domain)
        # pager
        pager = portal_pager(
            url="/my/tickets",
            url_args={'sortby': sortby, 'filterby': filterby, 'search_in': search_in, 'search': search},
            total=ticket_count,
            page=page,
            step=self._items_per_page,
        )
        # content according to pager and archive selected
        tickets = HelpdesTicket.sudo().search(domain, order=order, limit=self._items_per_page, offset=pager["offset"])
        print(tickets)

        values.update(
            {
                "date": date_begin,
                "tickets": tickets,
                "page_name": "ticket",
                "pager": pager,
                "default_url": "/my/tickets",
                "searchbar_sortings": searchbar_sortings,
                "sortby": sortby,
                'searchbar_inputs': searchbar_inputs,
                'search_in': search_in,
                "searchbar_filters": searchbar_filters,
                "filterby": filterby,
            }
        )
        return request.render("helpdesk_mgmt.portal_my_tickets", values)

