from odoo import models,fields

class inh_Users(models.Model):
    _inherit = 'res.users'

    helpdesk_team_id = fields.Many2one('helpdesk.ticket.team',string="Team")
