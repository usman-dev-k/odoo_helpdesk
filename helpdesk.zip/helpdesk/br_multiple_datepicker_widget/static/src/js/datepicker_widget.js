odoo.define('multiple_datepicker_widget.DatePickerWidget', function(require) {
    "use strict";

    var field_registry = require('web.field_registry');
    var fields = require('web.basic_fields');

    var DatePickerField = fields.InputField.extend({
        template: 'FieldDatePicker',

        events: _.extend({}, fields.InputField.prototype.events, {
            'click': '_onSelectDateField',
        }),

        _onSelectDateField: function(ev) {
            if (this.$input) {
                var today = new Date();
                var maxDate = new Date();
                maxDate.setDate(today.getDate() + 7);
                this.$input.datepicker({
                    startDate: today,
                    endDate: maxDate,
                    format: 'mm/dd/yyyy'
                }).trigger('focus');
            }
        },

    });

    field_registry.add('restricted_date_picker', DatePickerField);
    return {
        DatePickerField: DatePickerField
    };

});