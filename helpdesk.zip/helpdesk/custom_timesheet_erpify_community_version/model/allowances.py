from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import datetime
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DATE_FORMAT

call_out_on_call = {
    'simple_ediary': ['ONCALL', 'CALLOUT'],
    'activity_cdiary': ['ONCALL_A', 'ONCALL_B', 'ONCALL_AB', 'ONCALL_C', 'ONCALL_D', 'ONCALL_E', 'CALLOUT_R', 'CALLOUT_W'],
}


class Allowances(models.Model):
    _name = 'timesheet.allowances.category.erpify'
    _description = 'Timesheet Allowances Categories'

    @api.onchange('type')
    def _onchange_allowance_type(self):
        for allowance in self:
            if allowance.type != 'allowance':
                allowance.python_code = False

    name = fields.Char(required=True)
    applicable_day_ids = fields.Many2many('timesheet.config.days.erpify', 'timesheets_allowance_days_rel', 'allowance_id', 'day_id')
    type = fields.Selection([('overtime', 'Overtime'), ('ordinary', 'Ordinary'), ('nda', 'NDA'),
                             ('emergency', 'Emergency'), ('subs', 'Subsistence'), ('allowance', 'Claimable'),
                             ('late', 'Late')])
    is_substitution = fields.Boolean()
    is_oncall = fields.Boolean('Is On Call?')
    is_callout = fields.Boolean('Is Call Out?')
    salary_rule_id = fields.Many2one('hr.salary.rule', help='The salary rule that is linked to this timesheet allowance.')
    salary_rule_code = fields.Char(related='salary_rule_id.code', store=True, index=True, string='Code')
    np_salary_rule_id = fields.Many2one('hr.salary.rule', help='The salary rule that is linked to this timesheet allowance.', string='NP Salary Rule')
    np_salary_rule_code = fields.Char(related='np_salary_rule_id.code', store=True, index=True, string='NP Code')
    start = fields.Float('Start')
    end = fields.Float('End')
    active = fields.Boolean('Active', default=True, tracking=True)
    show_in_timesheet = fields.Boolean('Show while entering timesheets?', default=False)
    select_by_default = fields.Boolean('Select by Default?')
    apply_restriction = fields.Selection([('no', 'No'), ('schedule', "Based on Employee's Work Schedule"),
                                          ('define', 'As defined in Start and End time'), ('day', 'Specific Day of Week')], string='Apply Restrictions?', default='no')
    week_day = fields.Selection([('0', 'Monday'), ('1', 'Tuesday'), ('2', 'Wednesday'), ('3', 'Thursday'), ('4', 'Friday'),
                                 ('5', 'Saturday'), ('6', 'Sunday')])
    is_weekly = fields.Boolean('Is Claimable?', compute='get_is_claimable', store=True)
    python_code = fields.Text('Python Code')
    explanation = fields.Html('Help', default="""
     You can store the values in <code>result_amount</code> and <code>result_amount_np</code> variables. <br>
     <code>employee</code>: is the employee object from where you can access the data on employee record <br>
     The other available variables are: <code>hours, days, rate, number_of_calls, rank, team_code</code>""")
    x_rate = fields.Boolean('Rate %?')
    percentage_ids = fields.One2many('timesheet.allowance.percentage.erpify', 'allowance_category_id')
    x_days = fields.Boolean('Days?')
    x_hours = fields.Boolean('Hours?')
    x_team_code = fields.Boolean('Team Code?')
    x_rank = fields.Boolean('Rank?')
    x_number_of_calls = fields.Boolean('Number of Calls?')
    x_subsistence_table = fields.Boolean('Subsistence Table?')
    cant_be_with = fields.Many2one('timesheet.allowances.category.erpify', string="Can't Apply with")
    # Overtime
    rate_type = fields.Selection([('fix', 'Fixed'), ('param', 'Parameter Based')], default='fix')
    rate = fields.Float()
    ot_day = fields.Selection([('4', 'Mon-Fri'), ('5', 'Saturday'), ('6', 'Sunday')], string='Day Applicable')
    allow_any_day = fields.Boolean('Allow any Day?')
    ot_claim = fields.Selection([('auto', 'Automatic'), ('manual', 'Manual')], string='Overtime Claim?')
    limited = fields.Selection([('yes', 'Yes'), ('no', 'No')], default='no')
    s0to8 = fields.Boolean('00:00 to 08:00')
    s8to20 = fields.Boolean('08:00 to 20:00')
    s20to24 = fields.Boolean('20:00 to 24:00')
    s8to13 = fields.Boolean('08:00 to 13:00')
    s13to20 = fields.Boolean('13:00 to 20:00')
    # Rules
    rule_details = fields.One2many('timesheet.allowances.rules.details.erpify', 'main_rule_id', string='Parameters Details')
    limit = fields.Float('Weekly Limit')
    number_of_occurrences = fields.Integer(help='How many times it can appear in a weekly timesheet submission?')
    round_up = fields.Float('Round Up To?')
    # NDA
    nda_rate = fields.Float('NDA Rate')
    # Emergency
    min_hours_bef_midnight = fields.Float('Min. Hours Before Midnight', default=3)
    min_hours_aft_midnight = fields.Float('Min. Hours After Midnight', default=4)
    # Subsistence
    min_subs_time_spent = fields.Float('Min. Time Spent')
    subs_time_depart = fields.Float('Max. Time for Departure')
    subs_depart_relaxation_for = fields.Many2one('timesheet.allowances.category.erpify', 'Relaxation in Departure Time For')
    min_subs_time_return = fields.Float('Min. Time of Return')
    min_subs_distance = fields.Float('Min. Distance Travelled')
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.company.currency_id.id)
    subs_type = fields.Selection([('day', 'Day'), ('night', 'Night'), ('extra', 'Extra'), ('weekly', 'Weekly')], string='Subsistence Type')
    nda_type = fields.Selection([('ord', 'Ordinary'), ('ot', 'Overtime'), ('sun', 'Sunday'), ('ot-sun', 'Overtime Sunday')], string='NDA Type')
    help_erpify = fields.Text('Help')
    hours_between_bef = fields.Float('Hours Between')
    hours_between_aft = fields.Float('Hours After')
    # To Pay Leaves
    to_pay_timeoff = fields.Boolean('To Pay Hourly Time-Off?')

    def compute_values(self, submission_id):
        value = 0
        if self.type == 'nda':
            return self.get_nda(submission_id)
        elif self.type == 'emergency':
            return self.get_emergency(submission_id)
        elif self.type == 'subs':
            return 0
        return value

    # Methods for hourly rates and overtime rates need to be defined.

    def get_overtime(self, submission_id):
        # You will get the overtime hours.
        calc_hours = 0
        if submission_id.timesheet_type == 'time_appr_and_allw':
            overtime_hours = submission_id.total_ot_hours
            calc_hours = self.calculate_allowance_hours(overtime_hours)
        return calc_hours

    def get_emergency(self, submission_id):
        # You will get emergency hours
        overtime_hours = 0
        if submission_id.timesheet_type == 'time_appr_and_allw':
            overtime_hours = 0
            for line in submission_id.dairy_time_ids:
                overtime_hours += line.emergency_id.total_calc_emergency_hours
        return overtime_hours

    @api.depends('type')
    def get_is_claimable(self):
        for rec in self:
            if rec.type == 'allowance':
                rec.is_weekly = True
            else:
                rec.is_weekly = False

    def check_restriction(self, date, start, end, employee_id):
        if self.apply_restriction == 'no':
            return True
        elif self.apply_restriction == 'define':
            if self.end > start >= self.start and self.start < end <= self.end:
                return True
            else:
                raise ValidationError('Your start and ending time is not applicable for this work type.')
        elif self.apply_restriction == 'schedule':
            days = employee_id.resource_calendar_id.attendance_ids.filtered(lambda r: r.dayofweek == str(date.weekday()))
            s = min(days.mapped('date_from'))
            e = max(days.mapped('date_to'))
            if e > start >= s and s < end <= e:
                return True
            else:
                raise ValidationError('Your start and ending time is not applicable for this work type.')

    def calculate_allowance_hours(self, actual_hours, employee_id=False):
        rule = self
        if not rule:
            return actual_hours
        prev, hours = 0, 0
        if rule.round_up and actual_hours < rule.round_up:
            actual_hours = rule.round_up
        for line in rule.rule_details:
            if prev < actual_hours:
                hours += (line.upto * line.rate) if actual_hours > line.upto else ((actual_hours - prev) * line.rate)
                prev = line.upto
        return hours

    def get_rule(self, pay_scale):
        allowances = self.env['timesheet.allowances.category.erpify'].search([('type', '=', 'allowance')])
        alw_list = []
        for alw in allowances:
            if pay_scale.id in alw.applicable_to_ids.ids:
                alw_list.append(alw)
        return alw_list


class AllowanceRules(models.Model):
    _name = 'timesheet.allowances.rules.erpify'
    _description = 'Timesheet Allowances Rules'

    timesheet_allowance_categ_id = fields.Many2one('timesheet.allowances.category.erpify')
    applicable_to = fields.Many2many('resource.calendar')
    rule_details = fields.One2many('timesheet.allowances.rules.details.erpify', 'rule_id', string='Parameters Details')


class AllowanceRuleDetails(models.Model):
    _name = 'timesheet.allowances.rules.details.erpify'
    _description = 'Timesheet Allowances Rule Details'

    upto = fields.Float('Hours Upto')
    rate = fields.Float('Rate Multiplier')
    main_rule_id = fields.Many2one('timesheet.allowances.category.erpify')
    rule_id = fields.Many2one('timesheet.allowances.rules.erpify')


class SubsistanceTable(models.Model):
    _name = 'subsistence.table.erpify'
    _description = 'Subsistence Details'

    dayofweek = fields.Selection([
        ('0', 'Monday'),
        ('1', 'Tuesday'),
        ('2', 'Wednesday'),
        ('3', 'Thursday'),
        ('4', 'Friday'),
        ('5', 'Saturday'),
        ('6', 'Sunday')
    ], 'Day of Week', compute='get_week_day_from_date', default=False, store=True)

    @api.depends('date')
    def get_week_day_from_date(self):
        for rec in self:
            if rec.date:
                rec.dayofweek = str(rec.date.weekday())

    date = fields.Date()
    type = fields.Selection([('day', 'Day'), ('extra', 'Extra'), ('unight', 'Night'), ('weekly', 'Weekly')])
    how = fields.Char('How time was spent?')
    where = fields.Char('Where time was spent?')
    distance = fields.Float('Distance (km)')
    time_depart = fields.Float()
    time_return = fields.Float()
    timesheet_allowance_id = fields.Many2one('timesheet.submission.allowances.erpify')
    timesheet_submission_id = fields.Many2one('timesheet.submission.erpify')


class TimeDaysErpify(models.Model):
    _name = 'timesheet.config.days.erpify'
    _description = 'Days for Timesheets Config'
    _rec_name = 'name'

    code = fields.Integer()
    name = fields.Char()


class TimeAllowanceRates(models.Model):
    _name = 'timesheet.allowance.percentage.erpify'
    _description = 'Percentage for Timesheet Allowances'
    _rec_name = 'name'

    value = fields.Float(required=True)
    name = fields.Char(compute='get_rate_name', store=True)
    allowance_category_id = fields.Many2one('timesheet.allowances.category.erpify')

    @api.depends('value')
    def get_rate_name(self):
        for rec in self:
            rec.name = str(rec.value) + ' %'


class OnCallCallOutClaim(models.Model):
    _name = 'oncall.callout.claim.erpify'
    _description = 'OnCall/CallOut Claims'

    days = fields.Integer('Days')
    time_allowance_id = fields.Many2one('timesheet.submission.allowances.erpify')
