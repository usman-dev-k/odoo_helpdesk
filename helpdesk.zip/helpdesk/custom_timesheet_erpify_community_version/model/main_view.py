from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, timedelta, date
from odoo.tools import float_compare


class Emergency(models.Model):
    _name = 'timesheet.emergency.erpify'
    _description = 'Emergencies'

    submission_id = fields.Many2one('timesheet.submission.erpify')
    weekly_view_id = fields.Many2one('timesheet.weekly.view.erpify')
    line_ids = fields.One2many('timesheet.emergency.lines.erpify', 'emergency_id')
    date = fields.Date()
    s0to8 = fields.Float('00:00 to 08:00', compute='get_emergencies_duration', store=True)
    s8to20 = fields.Float('08:00 to 20:00', compute='get_emergencies_duration', store=True)
    s20to24 = fields.Float('20:00 to 24:00', compute='get_emergencies_duration', store=True)
    total_calc_emergency_hours = fields.Float('Total Calc. Emergencies', compute='get_emergencies_duration', store=True)
    no_of_emg = fields.Selection([('1', '1'), ('2', '2'), ('3', '3'), ('4', '4')], 'Number of Emergencies', default='1')
    description = fields.Char()

    @api.depends('line_ids', 'line_ids.s0to8', 'line_ids.s8to20', 'line_ids.s20to24', 'line_ids.calc_emergency_hours')
    def get_emergencies_duration(self):
        for rec in self:
            rec.s0to8 = rec.s8to20 = rec.s20to24 = rec.total_calc_emergency_hours = 0
            #applicable_emergency_rule_id = self.env['timesheet.allowances.category.erpify'].search()
            bef = 3.0  # rec.submission_id.applicable_emergency_rule_id.min_hours_bef_midnight
            aft = 4.0  # rec.submission_id.applicable_emergency_rule_id.min_hours_aft_midnight
            for line in rec.line_ids:
                if float_compare(rec.s8to20, 0, precision_digits=2) == 0:
                    rec.s8to20 += 0
                else:
                    rec.s8to20 = line.s8to20 if line.s8to20 >= bef else bef
                if float_compare(line.s0to8 + line.s20to24, 0, precision_digits=2) == 0:
                    to_add = 0
                else:
                    to_add = (line.s0to8 + line.s20to24) if (line.s0to8 + line.s20to24) >= aft else aft
                rec.s0to8 += to_add
                rec.s20to24 += to_add
                rec.total_calc_emergency_hours += line.calc_emergency_hours

    @api.model
    def create(self, vals_list):
        res = super(Emergency, self).create(vals_list)
        res.weekly_view_id.emergency_id = res.id
        return res


class EmergencyLines(models.Model):
    _name = 'timesheet.emergency.lines.erpify'
    _description = 'Emergencies'

    emergency_id = fields.Many2one('timesheet.emergency.erpify')
    s0to8 = fields.Float('00:00 to 08:00')
    s8to20 = fields.Float('08:00 to 20:00')
    s20to24 = fields.Float('20:00 to 24:00')
    seq = fields.Integer('Seq')
    seq_show = fields.Char('Emergency #', compute='get_seq_show', store=True)
    calc_emergency_hours = fields.Float(compute='get_calc_emergency_hours', store=True)

    @api.depends('s0to8', 's8to20', 's20to24')
    def get_calc_emergency_hours(self):
        for rec in self:
            bef = 3.0
            aft = 4.0
            if float_compare(rec.s8to20, 0, precision_digits=2) == 0:
                bef_mid = 0
            else:
                bef_mid = rec.s8to20 if rec.s8to20 >= bef else bef
            if float_compare(rec.s0to8 + rec.s20to24, 0, precision_digits=2) == 0:
                aft_mid = 0
            else:
                aft_mid = (rec.s0to8 + rec.s20to24) if (rec.s0to8 + rec.s20to24) >= aft else aft
            rec.calc_emergency_hours = bef_mid + aft_mid

    @api.depends('seq')
    def get_seq_show(self):
        for rec in self:
            rec.seq_show = str(rec.seq)

    @api.constrains('s0to8', 's8to20', 's20to24')
    def validate_time_entered(self):
        for rec in self:
            if rec.s0to8 and float_compare(rec.s0to8, 8.0, precision_digits=2) > 0:
                raise UserError('You cannot enter more than 8 hours in 0:00 to 8:00 slot.')
            if rec.s20to24 and float_compare(rec.s20to24, 4.0, precision_digits=2) > 0:
                raise UserError('You cannot enter more than 4 hours in 20:00 to 24:00 slot.')
            if rec.s8to20 and float_compare(rec.s8to20, 12.0, precision_digits=2) > 0:
                raise UserError('You cannot enter more than 12 hours in 8:00 to 20:00 slot.')


class TimesView(models.Model):
    _name = 'timesheet.weekly.view.erpify'
    _description = 'Weekly Timesheets View'

    @api.depends('dairy_date')
    def get_week_day_from_date(self):
        for rec in self:
            if rec.dairy_date:
                rec.day = str(rec.dairy_date.weekday())

    @api.depends('emergency_id', 'emergency_id.total_calc_emergency_hours')
    def get_emergency_hours(self):
        for rec in self:
            if rec.emergency_id:
                rec.emergency_hrs = rec.emergency_id.total_calc_emergency_hours
            else:
                rec.emergency_hrs = 0

    @api.depends('dairy_date')
    def get_dairy_date_show(self):
        for rec in self:
            if rec.dairy_date:
                rec.dairy_date_show = rec.dairy_date

    @api.depends('work_type')
    def get_work_type_show(self):
        for rec in self:
            if rec.work_type:
                rec.work_type_show = rec.work_type

    submission_id = fields.Many2one('timesheet.submission.erpify')
    dairy_date = fields.Date('Date')
    dairy_date_show = fields.Date('Date', compute='get_dairy_date_show', store=True)
    day = fields.Selection([
        ('0', 'Monday'),
        ('1', 'Tuesday'),
        ('2', 'Wednesday'),
        ('3', 'Thursday'),
        ('4', 'Friday'),
        ('5', 'Saturday'),
        ('6', 'Sunday')
    ], 'Day', compute='get_week_day_from_date', store=True)
    work_type = fields.Selection([('ord', 'Ordinary'), ('ot', 'Overtime')], string='Type')
    work_type_show = fields.Selection([('ord', 'Ordinary'), ('ot', 'Overtime')], string='Type', compute='get_work_type_show', store=True)
    s0to8 = fields.Float('00:00 to 08:00')
    s8to20 = fields.Float('08:00 to 20:00')
    s20to24 = fields.Float('20:00 to 24:00')
    sub_total = fields.Float(compute='get_sub_total', store=True)
    emergency_id = fields.Many2one('timesheet.emergency.erpify')
    emergency_hrs = fields.Float(compute='get_emergency_hours', store=True)
    # for SAT Overtime in eDiary
    sat_ot_id = fields.Many2one('timesheet.saturday.ot.erpify')
    s8to13 = fields.Float('08:00 to 13:00')
    s13to20 = fields.Float('13:00 to 20:00')

    def add_sat_overtime(self):
        view_id = self.env.ref('custom_timesheet_erpify_community_version.saturday_ot_popup_timesheet_submission_form_erpify').id
        action = {
                'name': _('Submit Saturday Overtime'),
                'view_mode': 'form',
                'views': [[view_id, 'form']],
                'res_model': 'timesheet.saturday.ot.erpify',
                'type': 'ir.actions.act_window',
                'target': 'new',
                'context': {'default_submission_id': self.submission_id.id,
                            'default_weekly_view_id': self.id}
            }
        if self.sat_ot_id:
            action.update({'res_id': self.sat_ot_id.id})
        if self.sat_ot_id and self.submission_id.state in ['draft', 'submit', 'schd_approved', 'approved', 'reject']:
            action.update({'context': {'default_submission_id': self.submission_id.id,
                                       'default_weekly_view_id': self.id, 'edit': False}})
        return action

    @api.depends('s0to8', 's8to20', 's20to24', 's8to13', 's13to20')
    def get_sub_total(self):
        for rec in self:
            rec.sub_total = rec.s0to8 + rec.s8to20 + rec.s20to24 + rec.s8to13 + rec.s13to20

    def add_emergencies(self):
        if self.submission_id.state != 'time' and not self.submission_id.payroll_edit_mode:
            raise ValidationError('You cannot change or add any emergencies once the request is submitted or approved.')
        view_id = self.env.ref('custom_timesheet_erpify_community_version.emergency_popup_timesheet_submission_form_erpify').id
        vals = []
        for i in range(1, 5):
            vals.append((0, 0, {
                'seq': i,
                's8to20': 0,
                's0to8': 0,
                's20to24': 0,
                'seq_show': str(i),
            }))
        action = {
                'name': _('Submit Emergencies'),
                'view_mode': 'form',
                'views': [[view_id, 'form']],
                'res_model': 'timesheet.emergency.erpify',
                'type': 'ir.actions.act_window',
                'target': 'new',
                'context': {'default_date': self.dairy_date, 'default_submission_id': self.submission_id.id,
                            'default_weekly_view_id': self.id, 'default_line_ids': vals}
            }
        if self.emergency_id:
            action.update({'res_id': self.emergency_id.id})
        return action

    @api.constrains('s0to8', 's8to20', 's20to24')
    def validate_time_entered(self):
        for rec in self:
            if rec.s0to8 and float_compare(rec.s0to8, 8.0, precision_digits=2) > 0:
                raise UserError('You cannot enter more than 8 hours in 0:00 to 8:00 slot.')
            if rec.s20to24 and float_compare(rec.s20to24, 4.0, precision_digits=2) > 0:
                raise UserError('You cannot enter more than 4 hours in 20:00 to 24:00 slot.')
            if rec.s8to20 and float_compare(rec.s8to20, 12.0, precision_digits=2) > 0:
                raise UserError('You cannot enter more than 12 hours in 8:00 to 20:00 slot.')
