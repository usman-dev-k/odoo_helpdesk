from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import datetime, timedelta, date
from odoo.tools import float_compare, DEFAULT_SERVER_DATE_FORMAT as DATE_FORMAT


class AppCode(models.Model):
    _name = 'appropriation.code'
    _description = 'Appropriation Codes'

    name = fields.Char(required=True)
    active = fields.Boolean(default=True)


class TimeCode(models.Model):
    _name = 'timesheet.time.code'
    _description = 'Timesheet Time Codes'

    name = fields.Char(required=True, string='Time Code')
    description = fields.Char()
    work_orders = fields.Char()
    active = fields.Boolean(default=True)


class ActivityCode(models.Model):
    _name = 'timesheet.activity.code'
    _description = 'Timesheet Activity Codes'

    name = fields.Char(required=True)
    active = fields.Boolean(default=True)


class Appropriations(models.Model):
    _name = 'timesheet.appropriations.erpify'
    _description = 'Appropriations'

    submission_id = fields.Many2one('timesheet.submission.erpify')
    ord_hrs = fields.Float('Ord Hours')
    ot_hrs = fields.Float('O/T Hours')
    app_code = fields.Many2one('appropriation.code', 'Appropriation Code')


class Submissions(models.Model):
    _inherit = 'timesheet.submission.erpify'

    total_ord_hours = fields.Float(compute='get_total_ord_ot_hours', store=True, string='Ordinary Hours')
    total_ot_hours = fields.Float(compute='get_total_ord_ot_hours', store=True, string='Overtime')
    ot_mon_fri = fields.Float(compute='get_total_ord_ot_hours', store=True, string='Overtime Mon-Fri')
    ot_sat = fields.Many2one('timesheet.weekly.view.erpify', compute='get_total_ord_ot_hours', store=True, string='Overtime Saturday')
    ot_sun = fields.Many2one('timesheet.weekly.view.erpify', compute='get_total_ord_ot_hours', store=True, string='Overtime Sunday')
    total_all_hours = fields.Float(compute='get_total_ord_ot_hours', store=True, string='Total Hours')
    appropriation_ids = fields.One2many('timesheet.appropriations.erpify', 'submission_id')
    appr_ord_hours = fields.Float(compute='get_appr_ord_ot_hours', store=True, string='Appr. Ordinary Hours')
    appr_ot_hours = fields.Float(compute='get_appr_ord_ot_hours', store=True, string='Appr. Overtime Hours')
    total_emergency_hrs = fields.Float(compute='get_total_ord_ot_hours', store=True, string='All Emergencies')

    @api.depends('appropriation_ids', 'appropriation_ids.ord_hrs', 'appropriation_ids.ot_hrs')
    def get_appr_ord_ot_hours(self):
        for rec in self:
            rec.appr_ord_hours = rec.appr_ot_hours = 0
            for line in rec.appropriation_ids:
                rec.appr_ord_hours += line.ord_hrs
                rec.appr_ot_hours += line.ot_hrs

    @api.depends('dairy_time_ids', 'dairy_time_ids.s0to8', 'dairy_time_ids.s8to20', 'dairy_time_ids.s20to24', 'dairy_time_ids.emergency_hrs',
                 'timesheet_ids', 'timesheet_ids.unit_amount', 'timesheet_ids.type_id_erpify')
    def get_total_ord_ot_hours(self):
        for rec in self:
            rec.total_ord_hours = rec.total_ot_hours = rec.total_all_hours = rec.total_emergency_hrs = rec.ot_mon_fri = 0
            rec.ot_sat = rec.ot_sun = False
            if rec.timesheet_type == 'time_appr_and_allw':
                for r in rec.dairy_time_ids:
                    if r.work_type == 'ord':
                        rec.total_ord_hours += r.sub_total
                    else:
                        if r.day in ['0', '1', '2', '3', '4']:
                            rec.ot_mon_fri += r.sub_total
                        elif r.day == '5' and r.sub_total:
                            rec.ot_sat = r.id
                        elif r.day == '6' and r.sub_total:
                            rec.ot_sun = r.id
                        rec.total_ot_hours += r.sub_total
                        rec.total_emergency_hrs += r.emergency_hrs
                    rec.total_all_hours += r.sub_total
                rec.total_all_hours += rec.total_emergency_hrs
            else:
                for r in rec.timesheet_ids:
                    if r.type_id_erpify.type == 'overtime':
                        rec.total_ot_hours += r.unit_amount
                    elif r.type_id_erpify.type == 'ordinary':
                        rec.total_ord_hours += r.unit_amount
                rec.total_all_hours = rec.total_ot_hours + rec.total_ord_hours

    def validate_appr_hours(self):
        for rec in self:
            if float_compare(rec.appr_ord_hours, rec.total_ord_hours, precision_digits=2) == 0 and float_compare(rec.appr_ot_hours, rec.total_ot_hours, precision_digits=2) == 0:
                continue
            if float_compare(rec.appr_ord_hours, rec.total_ord_hours, precision_digits=2) != 0 and float_compare(rec.appr_ot_hours, rec.total_ot_hours, precision_digits=2) != 0:
                raise ValidationError("There's a difference in the appropriated hours and ordinary + overtime hours. Please correct it first.")
            elif float_compare(rec.appr_ord_hours, rec.total_ord_hours, precision_digits=2) != 0 and float_compare(rec.appr_ot_hours, rec.total_ot_hours, precision_digits=2) == 0:
                raise ValidationError(
                    "There's a difference in the appropriated hours and ordinary hours. Please correct it first.")
            elif float_compare(rec.appr_ord_hours, rec.total_ord_hours, precision_digits=2) == 0 and float_compare(rec.appr_ot_hours, rec.total_ot_hours, precision_digits=2) != 0:
                raise ValidationError(
                    "There's a difference in the appropriated hours and overtime hours. Please correct it first.")


