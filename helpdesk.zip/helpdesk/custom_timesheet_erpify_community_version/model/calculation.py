from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import datetime, timedelta, date as date_obj


class TimeSheetCalculations(models.Model):
    _inherit = 'timesheet.submission.allowances.erpify'

    def calculate_hourly_basic(self):
        amount = self.hours * self.employee_id.get_hourly_rate()
        return amount

    def calculate_late(self):
        amount = self.hours * self.employee_id.get_hourly_rate() * -1
        return amount

    def calculate_oncall(self):
        if self.oncall_rate_id:
            amount = self.employee_id.get_parameter_value_by_code(self.oncall_rate_id.code)
            np_amount = self.employee_id.get_parameter_np_value_by_code(self.oncall_rate_id.code) if self.contract_id.basic_np_actual > 0.0 else 0.0
        else:
            amount, np_amount, days = 0, 0, 0
            np = True if self.contract_id.basic_np_actual > 0.0 else False
            for line in self.oncall_callout_ids:
                amount += self.employee_id.get_parameter_value_by_code(line.oncall_rate_id.code) * line.days
                days += line.days
                if np:
                    np_amount += self.employee_id.get_parameter_np_value_by_code(line.oncall_rate_id.code) * line.days
            self.days = days
        return amount, np_amount

    def calculate_callout(self):
        if self.callout_rate_id:
            amount = self.employee_id.get_parameter_value_by_code(self.callout_rate_id.code) * self.days
            np_amount = (self.employee_id.get_parameter_np_value_by_code(self.callout_rate_id.code) * self.days) if self.contract_id.basic_np_actual else 0
        else:
            amount, np_amount, days = 0, 0, 0
            np = True if self.contract_id.basic_np_actual else False
            for line in self.oncall_callout_ids:
                amount += self.employee_id.get_parameter_value_by_code(line.callout_rate_id.code) * line.days
                days += line.days
                if np:
                    np_amount += self.employee_id.get_parameter_np_value_by_code(line.callout_rate_id.code) * line.days
            self.days = days
        return amount, np_amount

    def calculate_overtime(self):
        amount = 0
        if self.name.rate_type == 'fix':
            # Manual overtime only
            amount = self.name.rate * self.hours
        else:
            overtime_hrs = self.hours
            base = 0
            if self.name.ot_day == '4':
                base = 0
                overtime_hrs += self.get_emergency(self.submission_request_id)
            elif self.name.ot_day == '5':
                if self.submission_request_id.timesheet_type == 'time_appr_and_allw':
                    base = self.submission_request_id.ot_mon_fri
                else:
                    base = self.timesheet_ids.filtered(lambda r: r.type_id_erpify.ot_day == '4').mapped('unit_amount')
            elif self.name.ot_day == '6':
                if self.submission_request_id.timesheet_type == 'time_appr_and_allw':
                    base = self.submission_request_id.ot_mon_fri + self.submission_request_id.ot_sat.sub_total
                else:
                    base = self.timesheet_ids.filtered(lambda r: r.type_id_erpify.ot_day in ['4', '5']).mapped('unit_amount')
            ot_params = self.name.param_ids.ids
            if self.submission_request_id.substitution_days >= 4:
                ot_rules = self.env['parameter.values.for.table.erpify'].search([('parameter_table_id', '=', self.substitution_grade_id.id), ('para_id', 'in', ot_params)])
            else:
                if self.employee_id.contract_id.parameter_ids:
                    ot_rules = self.env['parameter.values.for.employee.erpify'].search(
                        [('contract_id', '=', self.contract_id.id), ('para_id', 'in', ot_params)])
                else:
                    ot_rules = self.env['parameter.values.for.table.erpify'].search(
                        [('parameter_table_id', '=', self.employee_id.contract_id.grade_id.id), ('para_id', 'in', ot_params)])
            if not ot_rules:
                amount = overtime_hrs
            else:
                map_list = self.map_hours_with_rates(ot_rules, base, overtime_hrs)
                hours = 0
                for line in map_list:
                    hours += line[0] * line[1]
                amount = hours
        if self.name.limited == 'yes':
            if self.employee_id.contract_id.parameter_ids:
                limit_rule = self.env['parameter.values.for.employee.erpify'].search(
                    [('contract_id', '=', self.contract_id.id), ('para_id', '=', self.name.limit_para_id.id)])
            else:
                limit_rule = self.env['parameter.values.for.table.erpify'].search(
                    [('parameter_table_id', '=', self.employee_id.contract_id.grade_id.id),
                     ('para_id', '=', self.name.limit_para_id.id)])
            if limit_rule and limit_rule.value < amount:
                amount = limit_rule.value
        return amount  # multiply by hourly rate

    def map_hours_with_rates(self, rules, base, actual):
        if not rules:
            return [[actual, 1]]
        map_list = []
        for rule in rules:
            if base >= rule.upto:
                base -= rule.upto
                continue
            else:
                diff = rule.upto - base
                if diff >= actual:
                    map_list.append([actual, rule.value])
                    break
                else:
                    map_list.append([diff, rule.value])
                    actual -= diff
        return map_list

    def get_emergency(self, submission_id):
        # You will get emergency hours
        overtime_hours = 0
        if submission_id.timesheet_type == 'time_appr_and_allw':
            overtime_hours = 0
            for line in submission_id.dairy_time_ids:
                overtime_hours += line.emergency_id.total_calc_emergency_hours
        return overtime_hours

    def get_nda(self):
        # You will get the NDA hours.
        submission_id = self.submission_request_id
        amount = 0
        if submission_id.timesheet_type == 'time_appr_and_allw':
            overtime_hours = 0
            ot_params = self.name.param_ids.ids
            if self.employee_id.contract_id.parameter_ids:
                ot_rules = self.env['parameter.values.for.employee.erpify'].search(
                    [('contract_id', '=', self.contract_id.id), ('para_id', 'in', ot_params)])
            else:
                ot_rules = self.env['parameter.values.for.table.erpify'].search(
                    [('parameter_table_id', '=', self.employee_id.contract_id.grade_id.id),
                     ('para_id', 'in', ot_params)])
            for line in submission_id.dairy_time_ids:
                if self.name.nda_type == 'ord':
                    if line.work_type == 'ord' and line.day != '6':
                        overtime_hours += line.s0to8 + line.s20to24
                if self.name.nda_type == 'ot':
                    if line.work_type == 'ot' and line.day != '6':
                        overtime_hours += line.s0to8 + line.s20to24 + line.emergency_id.s0to8 + line.emergency_id.s20to24
                if self.name.nda_type == 'sun':
                    if line.work_type == 'ord' and line.day == '6':
                        overtime_hours += line.s0to8 + line.s20to24
                if self.name.nda_type == 'ot-sun':
                    if line.work_type == 'ot' and line.day == '6':
                        overtime_hours += line.s0to8 + line.s20to24 + line.emergency_id.s0to8 + line.emergency_id.s20to24
            if overtime_hours <= 0:
                return 0
            map_list = self.map_hours_with_rates(ot_rules, 0, overtime_hours)
            hours = 0
            for line in map_list:
                hours += line[0] * line[1]
            amount = hours
        return amount


class TimeSubmissions(models.Model):
    _inherit = 'timesheet.submission.erpify'

    def apply_automatic_overtime(self):
        if self.timesheet_type == 'time_appr_and_allw':
            ot_auto_timecodes = self.env['timesheet.allowances.category.erpify'].search([('type', '=', 'overtime'),
                                                                                         ('ot_claim', '=', 'auto')])
            applicable_ot_timecodes = ot_auto_timecodes.filtered(
                lambda r: self.pay_scale_id.id in r.applicable_to_ids.ids)
            if not applicable_ot_timecodes:
                return False
            for ot_timecode in applicable_ot_timecodes:
                hours = 0
                if ot_timecode.ot_day == '4':
                    hours = self.ot_mon_fri
                elif ot_timecode.ot_day == '5':
                    if ot_timecode.s0to8:
                        hours += self.ot_sat.s0to8
                    if ot_timecode.s8to20:
                        hours += self.ot_sat.s8to20
                    if ot_timecode.s20to24:
                        hours += self.ot_sat.s20to24
                    if ot_timecode.s8to13:
                        hours += self.ot_sat.s8to13
                    if ot_timecode.s13to20:
                        hours += self.ot_sat.s13to20
                elif ot_timecode.ot_day == '6':
                    hours = self.ot_sun.sub_total
                if hours > 0:
                    allowance_types_ids = self.allowances_ids.mapped('name.id')
                    if ot_timecode.id not in allowance_types_ids:
                        self.env['timesheet.submission.allowances.erpify'].create({
                            'name': ot_timecode.id,
                            'hours': hours,
                            'submission_request_id': self.id,
                            'employee_id': self.employee_id.id,
                        })
                    else:
                        timecode = self.allowances_ids.filtered(lambda r: r.name.id == ot_timecode.id)
                        timecode.hours = hours
        else:
            applicable_ord_timecodes = []
            ot_auto_timecodes = self.env['timesheet.allowances.category.erpify'].search([('type', '=', 'overtime'),
                                                                                         ('ot_claim', '=', 'manual')])
            applicable_ot_timecodes = ot_auto_timecodes.filtered(
                lambda r: self.pay_scale_id.id in r.applicable_to_ids.ids)
            if self.employee_id.contract_id == 'hourly':
                ord_timecodes = self.env['timesheet.allowances.category.erpify'].search([('type', '=', 'ordinary')])
                applicable_ord_timecodes = ord_timecodes.filtered(
                    lambda r: self.pay_scale_id.id in r.applicable_to_ids.ids).ids
            for time in self.timesheet_ids:
                if time.type_id_erpify.id in applicable_ot_timecodes.ids or time.type_id_erpify.id in applicable_ord_timecodes:
                    if time.unit_amount <= 0:
                        continue
                    allowance_types_ids = self.allowances_ids.mapped('name.id')
                    if time.type_id_erpify.id not in allowance_types_ids:
                        self.env['timesheet.submission.allowances.erpify'].create({
                            'name': time.type_id_erpify.id,
                            'hours': time.unit_amount,
                            'submission_request_id': self.id,
                            'employee_id': self.employee_id.id,
                        })
                    else:
                        timecode = self.allowances_ids.filtered(lambda r: r.name.id == time.type_id_erpify.id)
                        if self.employee_id.contract_id.contract_type == 'hourly' and time.type_id_erpify.type == 'ordinary':
                            timecode.hours = self.total_ord_hours
                        else:
                            timecode.hours += time.unit_amount

    def apply_automatic_nda(self):
        nda_timecodes = self.env['timesheet.allowances.category.erpify'].search([('type', '=', 'nda')])
        applicable_nda_timecodes = nda_timecodes.filtered(lambda r: self.pay_scale_id.id in r.applicable_to_ids.ids)
        if not applicable_nda_timecodes:
            return False
        if self.timesheet_type == 'time_appr_and_allw':
            allowance_types_ids = self.allowances_ids.mapped('name.id')
            for nda in applicable_nda_timecodes:
                if nda.id not in allowance_types_ids:
                    rec = self.env['timesheet.submission.allowances.erpify'].create({
                        'name': nda.id,
                        'hours': 0,
                        'submission_request_id': self.id,
                        'employee_id': self.employee_id.id,
                    })
                else:
                    rec = self.allowances_ids.filtered(lambda r: r.name.id == nda.id)
                value = rec.get_nda()
                if value > 0:
                    rec.hours = value
                else:
                    rec.sudo().unlink()

