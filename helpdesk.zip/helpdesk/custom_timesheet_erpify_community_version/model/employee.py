from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import datetime, timedelta, date
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DATE_FORMAT


class Employee(models.Model):
    _inherit = 'hr.employee'

    timesheets_hq_id = fields.Many2one('timesheets.hq.erpify', 'Timesheets HQ', track_visibility='onchange')
    time_sheets_type_erpify = fields.Selection(
        [('ot_and_allw', 'Simple Timesheets'), ('act_and_allw', 'Activity Code Timesheets'),
         ('time_appr_and_allw', 'eDiary Timesheets')], required=True, string='Timesheets Type', default='ot_and_allw',
        track_visibility='onchange')
    timesheet_period_erpify = fields.Selection([('1', 'Weekly'), ('4', 'Monthly')], string='Timesheets Period',
                                        default='1')
    oncall_rate_type = fields.Char(compute='get_oncall_callout_rate_type', store=True)
    call_out_rate_type = fields.Char(compute='get_oncall_callout_rate_type', store=True)
    project_id_erpify = fields.Many2one('project.project', 'Timesheet Project')
    time_in_lieu_balance = fields.Float('Time in Lieu Balance (hours)')

    def get_parameter_value_by_code(self, code):
        if self.contract_id.parameter_ids:
            para = self.env['parameter.values.for.employee.erpify'].search(
                [('contract_id', '=', self.contract_id.id), ('code', '=', str(code))])
        else:
            para = self.env['parameter.values.for.table.erpify'].search(
                [('parameter_table_id', '=', self.contract_id.grade_id.id), ('code', '=', str(code))])
        if para:
            return para.value
        else:
            return 0

    def get_parameter_np_value_by_code(self, code):
        if self.contract_id.parameter_ids:
            para = self.env['parameter.values.for.employee.erpify'].search(
                [('contract_id', '=', self.contract_id.id), ('code', '=', str(code))])
        else:
            para = self.env['parameter.values.for.table.erpify'].search(
                [('parameter_table_id', '=', self.contract_id.grade_id.id), ('code', '=', str(code))])
        if para:
            return para.np_value
        else:
            return 0

    def get_parameter_value_by_timecode(self, time_code_id):
        if self.contract_id.parameter_ids:
            para = self.env['parameter.values.for.employee.erpify'].search(
                [('contract_id', '=', self.contract_id.id), ('timecode', '=', time_code_id.id)])
        else:
            para = self.env['parameter.values.for.table.erpify'].search(
                [('parameter_table_id', '=', self.contract_id.grade_id.id), ('timecode', '=', time_code_id.id)])
        if para:
            return True if para.value > 0 else False
        else:
            return True

    def get_p_np_ratio(self):
        if self.contract_id and self.contract_id.basic_np_actual:
            return [100 - (self.contract_id.basic_np_actual / self.contract_id.basic_actual),
                    self.contract_id.basic_np_actual / self.contract_id.basic_actual]
        else:
            return [100, 0]

    def get_overtime_rate(self, payslip, values, not_include=[]):
        values = values.dict
        if not payslip.contract_id.grade_id:
            return 0
        overtime_rules = payslip.contract_id.grade_id.salary_rule_ids
        amount = 0
        for rule in overtime_rules:
            if rule.code not in not_include:
                amount += values.get(rule.code, 0)
        para_code = 'OTDIVISOR'
        ot_divisor = self.get_parameter_value_by_code(para_code)
        if ot_divisor:
            rate = round(amount / ot_divisor, 2)
        else:
            rate = 0
        return rate

    def get_hourly_rate(self, mode='all', para_code='OTDIVISOR'):
        if not self.contract_id:
            return 0
        if self.contract_id.hourly_paid_rate:
            if mode == 'np':
                return 0
            return self.contract_id.hourly_paid_rate
        if mode == 'np':
            amount = self.contract_id.basic_np_full_time
        elif mode == 'p':
            amount = self.contract_id.basic_full_time
        else:
            amount = self.contract_id.basic_full_time + self.contract_id.basic_np_full_time + self.contract_id.transiton_payment_part_time
        amount = amount / self.get_eir_divisor()
        ord_divisor = self.get_parameter_value_by_code(para_code)
        if ord_divisor:
            rate = round(amount / ord_divisor, 2)
        else:
            rate = 0
        return rate

    def get_week_amount_divisor_erpify(self):
        if self.contract_id.type_id.schedule_pay == '30':
            weeks = 4.348
        else:
            frequency = int(self.contract_id.type_id.schedule_pay)
            weeks = frequency / 7
        return weeks

    def get_amount_from_timesheet(self, code, time, np=False):
        time = time.dict
        code = str(code)
        allowance = self.env['account.analytic.line']
        timesheet = False
        if timesheet:
            allowance = self.env['account.analytic.line'].search([('type_id_erpify.salary_rule_code', '=', code), ('timesheet_submission_erpify_id', 'in', time)])
        else:
            domain = [('submission_request_id', 'in', time)]
            if np:
                categ_id = self.env['timesheet.allowances.category.erpify'].search([('np_salary_rule_code', '=', code)])
                domain.append(('name', '=', categ_id.id))
            else:
                categ_id = self.env['timesheet.allowances.category.erpify'].search([('salary_rule_code', '=', code), ('applicable_to_ids', 'in', [self.contract_id.grade_id.id])])
                domain.append(('name', '=', categ_id.id))
            allowance = self.env['timesheet.submission.allowances.erpify'].search(domain)
        if not allowance:
            return 0
        else:
            if timesheet:
                return sum(allowance.mapped('unit_amount')) * self.timesheet_cost
            elif not np:
                return sum(allowance.mapped('amount'))
            elif np:
                return sum(allowance.mapped('np_amount'))

    @api.depends('time_sheets_type_erpify')
    def get_oncall_callout_rate_type(self):
        for rec in self:
            if rec.time_sheets_type_erpify in ['ot_and_allw', 'time_appr_and_allw']:
                rec.oncall_rate_type = 'simple_ediary_oc'
                rec.call_out_rate_type = 'simple_ediary_co'
            else:
                rec.oncall_rate_type = 'activity_cdiary_oc'
                rec.call_out_rate_type = 'activity_cdiary_co'


class TimesheetsHQ(models.Model):
    _name = 'timesheets.hq.erpify'
    _description = 'Timesheets HQ'

    code = fields.Char()
    name = fields.Char()

    def name_get(self):
        res = []
        for record in self:
            name = record.name
            if record.code:
                name = "%(code)s - %(name)s" % {
                    'code': record.code,
                    'name': record.name,
                }
            res.append((record.id, name))
        return res


class Submissions(models.Model):
    _inherit = 'timesheet.submission.erpify'

    timesheets_hq_id = fields.Many2one('timesheets.hq.erpify', 'HQ', related='employee_id.timesheets_hq_id')
    temporary_hq_id = fields.Many2one('timesheets.hq.erpify', 'Temporary HQ')
