from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import datetime, timedelta, date as date_obj
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DATE_FORMAT


class TimeSheetTimeOff(models.Model):
    _name = 'timesheet.timeoff.erpify'
    _description = 'Time-Off and Timesheet'

    time_id = fields.Many2one('timesheet.submission.erpify')
    employee_id = fields.Many2one('hr.employee')
    date = fields.Date()
    day = fields.Selection([
        ('0', 'Monday'),
        ('1', 'Tuesday'),
        ('2', 'Wednesday'),
        ('3', 'Thursday'),
        ('4', 'Friday'),
        ('5', 'Saturday'),
        ('6', 'Sunday')], string='Day')
    leave_type_id = fields.Many2one('hr.leave.type')
    leave_type_request_unit = fields.Selection([
        ('day', 'Full Day'), ('half_day', 'Half Day'), ('hour', 'Hours')], string='Time Off Taken for', required=True)
    hours = fields.Float()


class TimeSheet(models.Model):
    _inherit = 'timesheet.submission.erpify'

    leave_entry_ids = fields.One2many('timesheet.timeoff.erpify', 'time_id')

    # def check_and_get_leaves(self):
    #     if self.leave_entry_ids:
    #         self.leave_entry_ids.sudo().unlink()
    #     entries = self.env['leaves.entry.erpify'].sudo().search([('employee_id', '=', self.employee_id.id),
    #                                                    ('date', '>=', self.start_date), ('date', '<=', self.end_date)])
    #     if entries:
    #         for e in entries:
    #             self.env['timesheet.timeoff.erpify'].create(
    #                 {
    #                     'time_id': self.id,
    #                     'employee_id': self.employee_id.id,
    #                     'date': e.date,
    #                     'day': e.day,
    #                     'leave_type_id': e.leave_type_id.id,
    #                     'leave_type_request_unit': e.leave_type_request_unit,
    #                     'hours': e.hours,
    #                 }
    #             )

    # def process_leaves_for_hourly_employees(self):
    #     time_type = self.env['timesheet.allowances.category.erpify'].search([('to_pay_timeoff', '=', True),('applicable_to_ids', 'in', [self.employee_id.contract_id.grade_id.id])], limit=1)
    #     if time_type:
    #         for leave in self.leave_entry_ids:
    #             self.env['account.analytic.line'].create({
    #                 'date': leave.date,
    #                 'employee_id': self.employee_id.id,
    #                 'description_erpify': 'Time-Off (hourly)',
    #                 'timesheet_submission_erpify_id': self.id,
    #                 'unit_amount': leave.hours,
    #                 'type_id_erpify': time_type.id,
    #                 'automated_erpify': True,
    #             })
