from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import datetime, timedelta, date as date_obj
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DATE_FORMAT
from odoo.tools import float_compare, float_is_zero
from odoo.tools.safe_eval import safe_eval
import calendar
import math


class helpdesk_ticket(models.Model):
    _inherit = 'project.task'

    @api.onchange('timesheet_ids')
    def get_the_hepldesk_ticket(self):
        for x in self.timesheet_ids:
            x.helpdesk_ticket = self.helpdesk_tickect.id


    timesheet_id = fields.Many2one('timesheet.submission.erpify', 'Idiary Timesheet')



class TimeSheetSubmissionAllowances(models.Model):
    _name = 'timesheet.submission.allowances.erpify'
    _description = 'Timesheets Allowances Submission'

    name = fields.Many2one('timesheet.allowances.category.erpify', index=True)
    hours = fields.Float()
    hours_after_TIL = fields.Float('Hours after TIL', help='Hours after applying Time in Lieu', compute=False,
                                   store=True)
    amount = fields.Float(compute=False, store=True)
    np_amount = fields.Float(compute=False, store=True, string='NP Amount')
    employee_id = fields.Many2one('hr.employee')
    contract_id = fields.Many2one('hr.contract', related='employee_id.contract_id')
    submission_request_id = fields.Many2one('timesheet.submission.erpify')
    currency_id = fields.Many2one(related='submission_request_id.currency_id')
    is_weekly = fields.Boolean(related='name.is_weekly')
    compute_amount = fields.Float()
    # Fields to show
    x_rate = fields.Boolean('Rate %?', related='name.x_rate')
    x_days = fields.Boolean('Days?', related='name.x_days')
    x_hours = fields.Boolean('Hours?', related='name.x_hours')
    x_team_code = fields.Boolean('Team Code?', related='name.x_team_code')
    x_rank = fields.Boolean('Rank?', related='name.x_rank')
    x_number_of_calls = fields.Boolean('Number of Calls?', related='name.x_number_of_calls')
    x_subsistence_table = fields.Boolean('Subsistence Table?', related='name.x_subsistence_table')
    x_is_substitution = fields.Boolean('Is Substitution?', related='name.is_substitution')
    is_oncall = fields.Boolean('Is On Call?', related='name.is_oncall')
    is_callout = fields.Boolean('Is Call Out?', related='name.is_callout')
    # Actual Fields
    rate_id = fields.Many2one('timesheet.allowance.percentage.erpify')
    rate = fields.Float('Rate %', related='rate_id.value')
    days = fields.Integer('Days')
    number_of_calls = fields.Integer('Number of Calls')
    subsistence_table = fields.One2many('subsistence.table.erpify', 'timesheet_allowance_id')
    filled = fields.Boolean('Claimed?', compute='_get_filled_or_not', store=True)
    start_date = fields.Date(related='submission_request_id.start_date')
    end_date = fields.Date(related='submission_request_id.end_date')
    subsistence_filled = fields.Boolean(compute='_get_subsistence_filled_or_not', store=True)
    oncall_rate_type = fields.Char(related='employee_id.oncall_rate_type')
    call_out_rate_type = fields.Char(related='employee_id.call_out_rate_type')
    oncall_callout_ids = fields.One2many('oncall.callout.claim.erpify', 'time_allowance_id')

    @api.depends('subsistence_table', 'subsistence_table.time_return', 'subsistence_table.time_depart')
    def _get_subsistence_filled_or_not(self):
        for rec in self:
            check = any(rec.subsistence_table.mapped('time_return'))
            if check:
                rec.subsistence_filled = True
            else:
                rec.subsistence_filled = False

    @api.depends('hours', 'rate', 'days', 'number_of_calls', 'subsistence_filled', 'oncall_callout_ids',
                 'oncall_callout_ids.days')
    def _get_filled_or_not(self):
        for rec in self:
            if rec.rate or rec.days or rec.team_code or rec.rank or rec.number_of_calls or rec.hours or rec.subsistence_filled or rec.oncall_callout_ids.mapped(
                    'days'):
                rec.filled = True
            else:
                rec.filled = False

    def compute_rule(self, localdict):
        for rec in self:
            localdict.update(**{
                'rate': rec.rate,
                'hours': rec.hours,
                'days': rec.days,
                'team_code': rec.team_code,
                'rank': rec.rank,
                'number_of_calls': rec.number_of_calls,
                'result_hours': 0.0,
                'result_amount': 0.0,
                'result_amount_np': 0.0,
                'employee': rec.submission_request_id.employee_id,
                'oncall_rate_id': rec.oncall_rate_id,
                'callout_rate_id': rec.callout_rate_id
            })
            if rec.name.python_code:
                safe_eval(rec.name.python_code or 0.0, localdict, mode='exec', nocopy=True)
                self.hours = localdict['result_hours'] if localdict['result_hours'] else self.hours
                self.compute_amount = self.amount = localdict['result_amount']
                self.np_amount = localdict['result_amount_np']
            elif rec.name.is_oncall:
                self.amount, self.np_amount = self.calculate_oncall()
            elif rec.name.is_callout:
                self.amount, self.np_amount = self.calculate_callout()
            elif rec.name.type == 'overtime':
                self.amount = self.calculate_overtime()
            elif rec.name.type == 'ordinary':
                self.amount = self.calculate_hourly_basic()
            elif rec.name.type == 'late':
                self.amount = self.calculate_late()
            elif rec.name.is_substitution:
                substitution_rate = self.employee_id.get_parameter_value_by_code('SUBSRATE')
                subs_divisor = self.employee_id.get_parameter_value_by_code('SUBSDIVISOR')
                if subs_divisor <= 0:
                    subs_divisor = 7
                self.amount = (self.days / subs_divisor) * substitution_rate
            elif rec.name.type == 'subs':
                if not rec.name.para_id:
                    raise ValidationError(
                        'No Parameter defined on the time allowance to calculate the subsistence rate.')
                self.amount = self.employee_id.get_parameter_value_by_code(rec.name.para_id.code) * self.days
            elif rec.name.type == 'nda':
                self.amount = self.employee_id.get_hourly_rate() * self.hours * self.name.nda_rate

    # @api.depends('hours', 'employee_id', 'days', 'rate', 'number_of_calls')
    # def get_amount(self):
    #     for r in self:
    #         if r.is_weekly:
    #             r.compute_rule({})
    #             r.amount = r.compute_amount
    #             #r.hours_after_TIL = 0
    #         else:
    #             til = r.hours - (r.hours * r.submission_request_id.time_in_lieu / 100)
    #             r.amount = til * r.employee_id.timesheet_cost
    #             #r.hours_after_TIL = til

    def add_data(self):
        if self.submission_request_id.state != 'allowance' and not self.submission_request_id.payroll_edit_mode:
            raise ValidationError(
                'You cannot change or add any allowance now, if you wish to do so, please go back to Claim Allowance stage.')
        view_id = self.env.ref(
            'custom_timesheet_erpify_community_version.allowance_popup_timesheet_submission_form_erpify').id
        return {
            'name': _('Submit Allowance Details'),
            'view_mode': 'form',
            'views': [[view_id, 'form']],
            'res_model': 'timesheet.submission.allowances.erpify',
            'type': 'ir.actions.act_window',
            'res_id': self.id,
            'target': 'new'
        }

    @api.model
    def default_get(self, fields_list):
        res = super(TimeSheetSubmissionAllowances, self).default_get(fields_list)
        return res

    # def write(self, vals):
    #     res = super(TimeSheetSubmissionAllowances, self).write(vals)
    #     # Write then check: otherwise, the use can create the timesheet in the future, then change
    #     # its date.
    #     return {'type': 'ir.actions.act_window_close'}


class Timesheets(models.Model):
    _inherit = 'account.analytic.line'



    idiary_timesheet_id = fields.Many2one('timesheet.submission.erpify', 'Task Timesheet')
    task_timesheet_id = fields.Many2one('project.task', 'Idiary Timesheet')

    # @api.onchange('project_id','project_task')
    # def chamge_project_id(self):
    #     if self._origin.id:
    #         if self.project_id or self.project_task:
    #             raise ValidationError('You cannot change project or task. Create a new one.')

    # @api.onchange('date', 'type_id_erpify', 'project_id', 'project_task', 'unit_amount', 'description_erpify')
    # def create_project_timesheet(self):

    #     for data in self:
    #         record = self.env['project.task'].search([('project_id', '=', self.project_id.id),('name','=',self.project_task.name)])
    #         if record:
    #             if data.description_erpify:
    #                 if data.description_erpify != '':
    #                     if record.timesheet_ids:
    #                         for x in record.timesheet_ids:
    #                             if data._origin.id == int(x.linking_id):
    #                                 x.date = data.date
    #                                 x.unit_amount = data.unit_amount
    #                                 x.name = data.description_erpify
    #                                 x.start = data.start
    #                                 x.end = data.end


    def unlink(self):
        self.timesheet_submission_erpify_id.get_warning_msg(False)
        # for data in self:
        #     record = self.env['project.task'].search([('project_id', '=', data.project_id.id),('name','=',data.project_task.name)])
        #     if record:
        #         if record.timesheet_ids:
        #             for x in record.timesheet_ids:
        #                 if data._origin.id == int(x.linking_id):
        #                     x.sudo().unlink()
        return super(Timesheets, self).unlink()

    @api.model
    def _get_ordinary_type(self):
        default = self.env['timesheet.allowances.category.erpify'].search([('type', '=', 'ordinary')], limit=1).id
        if default:
            return default
        else:
            return False

    @api.onchange('date')
    def get_account_id(self):
        if not self.account_id:
            self.account_id = 1


    linking_id = fields.Char(string='Link', store=True)
    project_id=fields.Many2one('project.project', string="Project" )
    project_name = fields.Char(string="Task", related='task_id.name')
    tz = fields.Selection(related='employee_id.tz', string='Time Zone', readonly=True, store=False)
    start = fields.Float(string="From")
    end = fields.Float(string="To")
    # name = fields.Char(string='Technicalss')
    description_erpify = fields.Char(string='Description')
    employee_shift_erpify = fields.Many2one('resource.calender')
    account_id = fields.Many2one('account.analytic.account',required="0")
    timesheet_submission_erpify_id = fields.Many2one('timesheet.submission.erpify')
    type_id_erpify = fields.Many2one('timesheet.allowances.category.erpify', string='Time Type',
                                     default=_get_ordinary_type)
    project_task = fields.Many2one('project.task', 'Project Task')

    time_code = fields.Many2one('timesheet.time.code', string='Time Code',)
    activity_code = fields.Many2one('timesheet.activity.code',string="Activity Code")
    helpdesk_ticket = fields.Many2one('helpdesk.ticket', string="Helpdesk Ticket")
    # helpdesk_ticket = fields.Many2one('helpdesk.ticket', string="Helpdesk Ticket", related='task_id.helpdesk_ticket.name')
    time_type_code = fields.Selection(related='type_id_erpify.type', string='Allowance Type')
    unit_amount = fields.Float(compute=False, store=True, string='Hours')
    calc_hours = fields.Float('Calculated Hours', compute=False, store=True)
    start_end_mand = fields.Boolean(related='employee_id.project_id_erpify.start_end_mand')
    # Activity Codes
    time_code_id = fields.Many2one('timesheet.time.code')
    activity_code_id = fields.Many2one('timesheet.activity.code')
    day = fields.Selection([
        ('0', 'Monday'),
        ('1', 'Tuesday'),
        ('2', 'Wednesday'),
        ('3', 'Thursday'),
        ('4', 'Friday'),
        ('5', 'Saturday'),
        ('6', 'Sunday')
    ], 'Day', compute='get_week_day_from_date', store=True)
    automated_erpify = fields.Boolean()
    recording_in_progress = fields.Boolean()
    rec_start_erpify = fields.Datetime()
    rec_stop_erpify = fields.Datetime()

    def start_recording(self):
        self.recording_in_progress = True
        self.rec_start_erpify = datetime.now()

    def stop_recording(self):
        self.rec_stop_erpify = datetime.now()
        diff = (self.rec_stop_erpify - self.rec_start_erpify).seconds
        hours = round(diff / 3600, 2)
        self.unit_amount += hours
        self.recording_in_progress = False
        title = _("Time Added %s hours!" % hours)
        txt = """<p style="background-color:white;color:#50D962;font-family: Arial, Helvetica, sans-serif;">
                    <strong>Latest Activity:</strong>
                    %s hours added to activity %s for %s dated %s.
                    </p>""" % (hours, self.activity_code_id.name, self.time_code_id.name,
                               self.date.strftime('%d/%m/%Y'))
        self.timesheet_submission_erpify_id.last_activity_rec_erpify = txt

    @api.depends('date')
    def get_week_day_from_date(self):
        for rec in self:
            if rec.date:
                rec.day = str(rec.date.weekday())

    @api.onchange('type_id_erpify', 'date')
    def onchange_domain_for_type_id_erpify(self):
        for record in self:
            return {
                'domain': {'type_id_erpify':
                               [('type', 'in', ['overtime', 'ordinary']), ('to_pay_timeoff', '=', False),
                                '|', ('ot_day', '<=', record.day), ('ot_day', 'in', [False, '4'])
                                ]},
            }

    @api.depends('start', 'end', 'type_id_erpify', 'employee_id', 'unit_amount')
    def calculate_calculated_hours(self):
        for record in self:
            if record.type_id_erpify and record.employee_id:
                record.calc_hours = record.type_id_erpify.calculate_allowance_hours(record.unit_amount,
                                                                                    record.employee_id)

    # @api.constrains('calc_hours')
    # def check_limit_erpify(self):
    #     for record in self:
    #         rule = record.type_id_erpify.get_rule(record.employee_id.resource_calendar_id)
    #         if rule and rule.limited == 'yes':
    #             if rule.number_of_occurences:
    #                 week_start = record.date - datetime.timedelta(days=record.date.weekday())
    #                 week_end = record.date + datetime.timedelta(days=6 - record.date.weekday())
    #                 timesheet_entries = self.env['account.analytic.line'].search([('employee_id', '=', record.employee_id.id), ('date', '>=', week_start), ('date', '<=', week_end),
    #                                                           ('type_id_erpify', '=', record.type_id_erpify.id)])
    #                 if timesheet_entries and len(timesheet_entries) + 1 > rule.number_of_occurences:
    #                     raise ValidationError("Your limit to apply for this work type has been reached for this week, please try any other work type.")
    #             if rule.limit:
    #                 timesheet_entries = self.env['account.analytic.line'].search(
    #                     [('employee_id', '=', record.employee_id.id), ('date', '=', record.date),
    #                      ('type_id_erpify', '=', record.type_id_erpify.id)])
    #                 if sum(timesheet_entries.mapped('calc_hours')) + record.calc_hours > rule.limit:
    #                     raise ValidationError(
    #                         "Your limit to apply for this work type has been reached for this day, please try any other work type.")

    @api.model
    def create(self, vals):
        if not vals.get('name', False):
            vals.update({'name': '/'})
        if not vals.get('employee_id', False):
            employee = self.env['hr.employee'].search([('user_id', '=', self.env.user.id)])
        else:
            emp = vals.get('employee_id', False)
            employee = self.env['hr.employee'].sudo().search([('id', '=', emp)])
        result = super(Timesheets, self).create(vals)
        result.calculate_duration()
        if result.type_id_erpify.ot_day and not result.type_id_erpify.allow_any_day:
            check_day = result.date.weekday()
            if result.type_id_erpify.ot_day == '4' and check_day > int(result.type_id_erpify.ot_day):
                raise ValidationError('You can only use this Time Type between Monday to Friday.')
            elif result.type_id_erpify.ot_day in ['5', '6'] and check_day != int(result.type_id_erpify.ot_day):
                eng_day = calendar.day_name[int(result.type_id_erpify.ot_day)]
                raise ValidationError('You can only use this Time Type for %s.' % eng_day)
        if result.sudo().employee_id:
            result.employee_shift_erpify = result.sudo().employee_id.resource_calendar_id.id
        for r in result:
            r.check_absence_entries_for_date(r.date)




        for data in result:
            if data.project_task:
                data.task_id = data.project_task.id
                data.idiary_timesheet_id = data.timesheet_submission_erpify_id.id 
            if data.task_id:
                data.project_task = data.task_id.id
                data.timesheet_submission_erpify_id = data.idiary_timesheet_id.id

            
        #     record = self.env['project.task'].sudo().search([('project_id', '=', data.project_id.id),('name','=',data.project_task.name)])
        #     if record:
        #         if data.description_erpify:
        #             if data.description_erpify != '':
        #                 if record.timesheet_ids:
        #                     timesheet_rec_2 = {}
        #                     for x in record.timesheet_ids:
        #                         if data._origin.id == int(x.linking_id):
        #                             x.date = data.date
        #                             x.unit_amount = data.unit_amount
        #                             x.name = data.description_erpify
        #                             x.start = data.start
        #                             x.end = data.end

        #                         else:
        #                             timesheet_rec_2 = {
        #                                 'date': data.date,
        #                                 'unit_amount': data.unit_amount,
        #                                 'project_id': data.project_id.id,
        #                                 'name': data.description_erpify,
        #                                 'linking_id': data._origin.id,
        #                                 'start': data.start,
        #                                 'end': data.end,
        #                             }
        #                     if timesheet_rec_2 != {}:
        #                         record.timesheet_ids = [(0, 0, timesheet_rec_2)]
        #                 else:
        #                     timesheet_rec = {
        #                         'date': data.date,
        #                         'unit_amount': data.unit_amount,
        #                         'project_id': data.project_id.id,
        #                         'name': data.description_erpify,
        #                         'linking_id': data._origin.id,
        #                         'start': data.start,
        #                         'end': data.end,
        #                     }
        #                     record.timesheet_ids = [(0, 0, timesheet_rec)]
        return result

    def write(self, vals):
        res = super(Timesheets, self).write(vals)
        for rec in self:
            rec.check_absence_entries_for_date(rec.date)
        return res

    def check_absence_entries_for_date(self, date_provided):
        if self.sudo().employee_id.id:
            return True
        if not self.sudo().employee_id.contract_id:
            raise ValidationError('You do not have an active contract in the system to submit the timesheets,'
                                  ' please contact HR.')
        if self.type_id_erpify.type == 'overtime':
            return True
        absences = self.env['hr.leave.type'].search([])
        absence_projects = list(set(absences.mapped('timesheet_project_id.id')))

        if absences:
            leaves_found = self.env['account.analytic.line'].search(
                [('employee_id', '=', self.sudo().employee_id.id), ('date', '=', date_provided),
                 ('project_id', 'in', absence_projects)])
            if leaves_found:
                self.timesheet_submission_erpify_id.get_warning_msg(True)
            elif leaves_found and float_is_zero(self.unit_amount, precision_rounding=2):
                self.timesheet_submission_erpify_id.get_warning_msg(False)
        entries_found = self.env['account.analytic.line'].search(
            [('employee_id', '=', self.sudo().employee_id.id), ('date', '=', date_provided),
             ('project_id', 'not in', absence_projects), ('id', '!=', self.id)])
        if entries_found:
            to_add = sum(entries_found.mapped('unit_amount'))
        else:
            to_add = 0
        per_day = 24
        if self.project_id.id not in absence_projects and (self.unit_amount + to_add > per_day):
            raise ValidationError(
                'Date: %s : You cannot claim more than 24 hours for a single day.' % date_provided.strftime("%d-%b-%Y"))

    @api.onchange('start', 'end')
    def calculate_duration(self):
        for r in self:
            if r.start and r.end:
                r.unit_amount = r.end - r.start
            else:
                r.unit_amount = r.unit_amount

    @api.constrains('start', 'end', 'type_id_erpify')
    def check_validaty_of_start_end(self):
        if self.start > 24:
            raise ValidationError('The starting time entered is not correct')
        if self.end > 24:
            raise ValidationError('The ending time entered is not correct')
        if self.start > self.end:
            raise ValidationError('The starting time can not be earlier than ending time.')
        self.type_id_erpify.sudo().check_restriction(self.date, self.start, self.end, self.sudo().employee_id)


class TimeSheetSubmission(models.Model):
    _name = 'timesheet.submission.erpify'
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']
    _description = 'Timesheets Request'

    def copy(self, default=None):
        timesheet = self.env['timesheet.submission.erpify'].search([('employee_id', '=', self.employee_id.id)],
                                                                   order='end_date desc', limit=1)
        if timesheet and timesheet.timesheet_period:
            duration = timedelta(weeks=int(timesheet.timesheet_period))
            start = timesheet.start_date + duration
            end = timesheet.end_date + duration
            default = {'start_date': start, 'end_date': end}
            new_timesheet = super(TimeSheetSubmission, self).copy(default=default)
            for i, line in enumerate(new_timesheet.timesheet_ids.sorted(lambda k: k.date)):
                line.date = start + timedelta(days=i)
        else:
            new_timesheet = super(TimeSheetSubmission, self).copy(default=default)
        return new_timesheet

    def re_allocate_time_entries(self):
        time_entries = self.env['account.analytic.line'].search([('employee_id', '=', self.employee_id.id),('date', '>=', self.start_date),('date', '<=', self.end_date),('timesheet_submission_erpify_id', 'not in',[False, self.id])])
        if time_entries:
            for time in time_entries:
                self.timesheet_ids = [(4, time.id)]

    def unlink(self):
        if self.state not in ['week', 'time', 'reject']:
            raise ValidationError('You can only delete a timesheet that is either in time entry phase or rejected.')
        self.timesheet_ids.unlink()
        return super(TimeSheetSubmission, self).unlink()

    def button_send_back_to_employee(self):
        if self.env.user not in [self.sudo().manager_id.user_id, self.sudo().manager_id.user_id,
                                 self.sudo().manager_id.parent_id.user_id if self.sudo().manager_id.parent_id else False]:
            raise ValidationError('You cannot send this request back, only the line manager or his manager or'
                                  ' a delegated manager can do it.')
        if self.env.user.id == self.sudo().manager_id.user_id.id and self.env.user.id == self.sudo().employee_id.user_id.id and self.sudo().manager_id.parent_id:
            raise ValidationError(
                'You cannot send back your own request, please ask %s to do it.' % self.sudo().manager_id.parent_id.name)
        if self.captured_in_payroll:
            raise ValidationError('You cannot send back a timesheet that is already processed by Payroll.')
        pending = self.employee_id.slip_ids.filtered(lambda r: r.state in ['draft', 'verify'])
        if pending and self.state == 'approved' and (self.env.user.company_id.lock_transaction_erpify or
                                                     self.employee_id.company_id.lock_transaction_erpify):
            raise ValidationError(
                "You cannot modify this record because a payroll is already processing it.")
        self.state = self.state2 = 'draft'





    @api.onchange('employee_id', 'end_date')
    def can_edit_employee_id(self):
        for rec in self:
            current_user = self.env['hr.employee'].sudo().search([('user_id', '=', self.env.user.id)])
            if current_user.child_ids:
                sub_team = self.env['hr.employee'].sudo().search([('parent_id.parent_id.user_id', '=', self.env.user.id)])
                if sub_team:
                    allowed = current_user.child_ids.ids + [current_user.id] + sub_team.ids
                else:
                    allowed = current_user.child_ids.ids + [current_user.id]
            else:
                allowed = [current_user.id]

            return {'domain': {'employee_id_sel': [('id', 'in', allowed)]}}

    can_edit_emp = fields.Boolean(compute=False)
    substitution_days = fields.Float()
    payroll_edit_mode = fields.Boolean(copy=False)
    is_changed = fields.Boolean(copy=False)

    def button_activate_payroll_edit_mode(self):
        self.payroll_edit_mode = True
        self._message_log(
            body=_(
                'Payroll Edit Mode initiated by %s.' % self.env.user.name))

    def button_deactivate_payroll_edit_mode(self):
        to_delete = self.allowances_ids.filtered(lambda r: r.name.type in ['overtime', 'ordinary'])
        to_delete.unlink()
        self.apply_automatic_overtime()
        self.apply_automatic_nda()
        self.apply_subsistence()
        self.calculate_weekly_allowances()
        self.payroll_edit_mode = False
        self._message_log(
            body=_(
                'Payroll Edit Mode closed by %s.' % self.env.user.name))
        self.is_changed = True

    @api.constrains('employee_id', 'start_date', 'end_date')
    def check_employee_and_dates(self):
        found = self.env['timesheet.submission.erpify'].search(
            [('employee_id', '=', self.employee_id.id), ('start_date', '=', self.start_date),
             ('end_date', '=', self.end_date), ('id', '!=', self.id)])
        if found:
            raise ValidationError('%s has already created a submission for this duration.' % self.employee_id.name)

    @api.model
    def default_get(self, field_list):
        result = super(TimeSheetSubmission, self).default_get(field_list)
        if 'employee_id' in field_list:
            result['employee_id'] = self.env['hr.employee'].search([('user_id', '=', self.env.uid)], limit=1).id
            result['employee_id_sel'] = self.env['hr.employee'].search([('user_id', '=', self.env.uid)], limit=1).id
        return result

    def get_start_date(self):
        today = fields.Date.today()
        if self.timesheet_period == '4':
            return today.replace(day=1)
        else:
            current_weekday = today.weekday()
            return today - timedelta(days=current_weekday)

    def get_end_date(self):
        today = fields.Date.today()
        if self.timesheet_period == '4':
            last = calendar.monthrange(today.year, today.month)[1]
            return today.replace(day=last)
        else:
            current_weekday = today.weekday()
            return today + timedelta(days=6 - current_weekday)

    @api.onchange('employee_id_sel')
    def get_employee_id_erpify(self):
        for rec in self:
            if rec.employee_id_sel:
                rec.sudo().employee_id = rec.employee_id_sel.id

    timesheet_id = fields.Many2one('project.task', 'Task Timesheet')
    name = fields.Char(compute='_get_record_name', store=True)
    start_date = fields.Date(required=True, default=get_start_date, copy=False)
    end_date = fields.Date(required=True, default=get_end_date, copy=False)
    employee_id_sel = fields.Many2one('hr.employee.public', 'Employee')
    employee_id = fields.Many2one('hr.employee', required=True)
    timesheet_type = fields.Selection(
        [('ot_and_allw', 'Simple Timesheets'), ('act_and_allw', 'Activity Code Timesheets'),
         ('time_appr_and_allw', 'eDiary Timesheets')],
        related='employee_id.time_sheets_type_erpify', store=True)
    timesheet_period = fields.Selection([('1', 'Weekly'), ('4', 'Monthly')],
                                        related='employee_id.timesheet_period_erpify', store=True)
    timesheet_ids = fields.One2many('account.analytic.line', 'timesheet_submission_erpify_id', copy=True)
    dairy_time_ids = fields.One2many('timesheet.weekly.view.erpify', 'submission_id')
    subsistence_ids = fields.One2many('subsistence.table.erpify', 'timesheet_submission_id')
    state = fields.Selection([('week', 'Week Selection'), ('time', 'Time Entry'), ('allowance', 'Claim Allowances'),
                              ('subs', 'Claim Subsistence'), ('appr', 'Appropriation'),
                              ('draft', 'Review'), ('submit', 'Submitted'), ('schd_approved', 'Approved'),
                              ('approved', 'Ready to Pay'), ('reject', 'Rejected')],
                             default='week', string='Status', track_visibility='onchange')
    state2 = fields.Selection([('week', 'Week Selection'), ('time', 'Time Entry'), ('allowance', 'Claim Allowances'),
                               ('draft', 'Review'), ('submit', 'Submitted'), ('schd_approved', 'Approved'),
                               ('approved', 'Ready to Pay'), ('reject', 'Rejected')],
                              compute='get_status2', string='Status', store=True)
    approval_matrix = fields.One2many('timesheet.approval.matrix', 'timesheet_submission_id')
    company_id = fields.Many2one('res.company', string='Company', index=True, default=lambda self: self.env.company)
    currency_id = fields.Many2one(related='company_id.currency_id')
    submission_date = fields.Datetime(copy=False)
    allowances_ids = fields.One2many('timesheet.submission.allowances.erpify', 'submission_request_id')
    allowance_total = fields.Float('Allowances (Amount)', compute='_compute_all_amounts', store=True)
    normal_total = fields.Float('Basic Pay', compute='_compute_all_amounts', store=True)
    total_amount = fields.Float(compute='_compute_all_amounts', store=True)
    manager_id = fields.Many2one('hr.employee', related='employee_id.parent_id')

    account_id = fields.Many2one('account.account' , string="Account" )
    instructions = fields.Html('Instructions', compute='get_instructions', store=True)
    message = fields.Html('Warning')
    latest_date = fields.Date(compute='_compute_latest_date_entered', store=True)
    last_activity_rec_erpify = fields.Html('Last Activity')

    @api.depends('timesheet_ids', 'start_date', 'timesheet_ids.date')
    def _compute_latest_date_entered(self):
        for rec in self:
            if rec.timesheet_ids:
                latest = rec.timesheet_ids.sorted(lambda r: r.date)
                rec.latest_date = latest[-1].date
            else:
                rec.latest_date = rec.start_date

    def get_warning_msg(self, msg):
        for rec in self:
            if msg:
                rec.message = """<p style="background-color:white;color:#f5b042;font-family: Arial, Helvetica, sans-serif;">
                        <strong>Warning: </strong>
                        Please note that you have taken leave for some day(s) in this timesheets.
                        </p>"""
            else:
                rec.message = False

    def get_approval_date(self):
        if not self.approval_matrix:
            return ''
        approved_at = self.approval_matrix.mapped('checked_at')[-1]
        return approved_at

    @api.depends('state')
    def get_status2(self):
        for rec in self:
            if rec.state not in ['subs', 'appr']:
                rec.state2 = rec.state
            else:
                rec.state2 = rec.state2

    def button_next_erpify(self):
        if self.state == 'time':
            # self.check_substitution_claim()
            if self.timesheet_type != 'time_appr_and_allw':
                faulty_records = self.timesheet_ids.filtered(
                    lambda r: self.end_date < r.date or r.date < self.start_date)
                if faulty_records:
                    raise ValidationError(
                        'You have entered %s record(s) that do not lie in the timesheet week you selected. Please correct them.' % len(
                            faulty_records))
            self.state = 'allowance'
            self.apply_automatic_overtime()
            self.apply_automatic_nda()
        elif self.state == 'subs':
            self.validate_subsistence()
            self.state = 'appr'
        elif self.state == 'appr':
            self.apply_subsistence()
            if self.env.context.get('added_by_web_erpify', False):
                self.validate_appr_hours()
            self.calculate_weekly_allowances()
            self.state = 'draft'
        elif self.state == 'allowance':
            if self.timesheet_type == 'time_appr_and_allw':
                self.state = 'subs'
            else:
                self.calculate_weekly_allowances()
                self.state = 'draft'

    def apply_subsistence(self):
        sub_day = self.env['timesheet.allowances.category.erpify'].search([('subs_type', '=', 'day')])
        sub_night = self.env['timesheet.allowances.category.erpify'].search([('subs_type', '=', 'night')])
        sub_extra = self.env['timesheet.allowances.category.erpify'].search([('subs_type', '=', 'extra')])
        sub_weekly = self.env['timesheet.allowances.category.erpify'].search([('subs_type', '=', 'weekly')])
        data = {
            'day': ['day', sub_day, 0],
            'unight': ['night', sub_night, 0],
            'extra': ['extra', sub_extra, 0],
            'weekly': ['weekly', sub_weekly, 0],
        }
        for subsistence in self.subsistence_ids:
            if subsistence.type:
                data[subsistence.type][2] += 1
                if subsistence.type == 'extra':
                    data['day'][2] += 1

        for key, value in data.items():
            if value[2] > 0:
                timecode = self.allowances_ids.filtered(lambda r: r.name.id == value[1].id)
                if not timecode:
                    self.env['timesheet.submission.allowances.erpify'].create({
                        'name': value[1].id,
                        'days': value[2],
                        'submission_request_id': self.id,
                        'employee_id': self.employee_id.id,
                    })
                else:
                    timecode.days = value[2]

    def validate_subsistence(self):
        days = self.env['timesheet.allowances.category.erpify'].search([('subs_type', '=', 'day')])
        day_rule = days.filtered(lambda r: self.pay_scale_id.id in r.applicable_to_ids.ids)
        nights = self.env['timesheet.allowances.category.erpify'].search([('subs_type', '=', 'night')])
        night_rule = nights.filtered(lambda r: self.pay_scale_id.id in r.applicable_to_ids.ids)
        weekly = self.env['timesheet.allowances.category.erpify'].search([('subs_type', '=', 'weekly')])
        weekly_rule = weekly.filtered(lambda r: self.pay_scale_id.id in r.applicable_to_ids.ids)
        extra = self.env['timesheet.allowances.category.erpify'].search([('subs_type', '=', 'extra')])
        extra_rule = extra.filtered(lambda r: self.pay_scale_id.id in r.applicable_to_ids.ids)
        claimed_allowances = self.allowances_ids.filtered(lambda r: r.filled).mapped('name.id')
        for line in self.subsistence_ids:
            if not line.type:
                continue
            if not line.how:
                raise ValidationError('You need to enter how time was spent for %s' % calendar.day_name[
                    int(line.dayofweek)])
            if not line.where:
                raise ValidationError('You need to enter where time was spent for %s' % calendar.day_name[
                    int(line.dayofweek)])
            if line.type == 'day':
                if not day_rule:
                    raise ValidationError('No rules found for claiming a day subsistence for your pay-scale/grade.')
                rule = day_rule
            if line.type == 'unight':
                if not night_rule:
                    raise ValidationError('No rules found for claiming a night subsistence for your pay-scale/grade.')
                rule = night_rule
            if line.type == 'weekly':
                if not weekly_rule:
                    raise ValidationError('No rules found for claiming a weekly subsistence for your pay-scale/grade.')
                rule = weekly_rule
            if line.type == 'extra':
                if not extra_rule:
                    raise ValidationError('No rules found for claiming a weekly subsistence for your pay-scale/grade.')
                rule = extra_rule

            if rule[0].min_subs_time_spent and (rule[0].min_subs_time_spent > line.time_return - line.time_depart):
                raise ValidationError(
                    'For %s, the time spent is not sufficient to claim subsistence.' % calendar.day_name[
                        int(line.dayofweek)])
            if rule[0].subs_time_depart and (rule[0].subs_time_depart < line.time_depart and rule[0].subs_depart_relaxation_for.id not in claimed_allowances):
                raise ValidationError(
                    'For %s, the departure time is too late to claim subsistence.' % calendar.day_name[
                        int(line.dayofweek)])
            if rule[0].min_subs_time_return and (rule[0].min_subs_time_return > line.time_return):
                raise ValidationError('For %s, the return time is too early to claim subsistence.' % calendar.day_name[
                    int(line.dayofweek)])
            if rule[0].min_subs_distance and (rule[0].min_subs_distance > line.distance):
                raise ValidationError(
                    'For %s, the distance travelled is not sufficient to claim subsistence.' % calendar.day_name[
                        int(line.dayofweek)])

    def button_back_erpify(self):
        if self.state == 'subs':
            to_delete = self.allowances_ids.filtered(lambda r: r.name.type in ['overtime', 'ordinary'])
            to_delete.unlink()
            self.state = 'allowance'
        elif self.state == 'appr':
            self.state = 'subs'
        elif self.state == 'allowance':
            self.state = 'time'
            to_delete = self.allowances_ids.filtered(lambda r: r.name.type == 'overtime')
            to_delete.unlink()
        elif self.state == 'draft':
            if self.timesheet_type == 'time_appr_and_allw':
                subsistence_to_revert = self.allowances_ids.filtered(lambda r: r.name.type == 'subs')
                subsistence_to_revert.sudo().unlink()
                self.state = 'appr'
            else:
                to_delete = self.allowances_ids.filtered(lambda r: r.name.type == 'overtime')
                to_delete.unlink()
                self.state = 'allowance'

    @api.depends('state')
    def get_instructions(self):
        for rec in self:
            txt = """<p style="background-color:white;color:#4D999F;font-family: Arial, Helvetica, sans-serif;">
            <strong>Notes:</strong>
            %s
            </p>"""
            if rec.state == 'week':
                ins = "Please select the week dates and click on proceed."
                rec.instructions = txt % (ins)
            elif rec.state == 'time':
                ins = "Please enter your time spent for this week and then click on next."
                rec.instructions = txt % (ins)
            elif rec.state == 'subs':
                ins = "Please claim subsistence for this week if needed and then click on next."
                rec.instructions = txt % (ins)
            elif rec.state == 'appr':
                ins = "Please add appropriations and then click on next."
                rec.instructions = txt % (ins)
            elif rec.state == 'allowance':
                ins = "Please claim allowances for this week and then click on next."
                rec.instructions = txt % (ins)
            elif rec.state == 'draft':
                ins = "Please review all the inputs and then submit your timesheets for approval."
                rec.instructions = txt % (ins)
            elif rec.state == 'submit':
                ins = "Thank you. Your timesheets are now forwarded to your line manager for approval."
                rec.instructions = txt % (ins)
            elif rec.state == 'schd_approved':
                ins = "Your timesheets are now approved, but scheduled for the next payroll."
                rec.instructions = txt % (ins)
            elif rec.state == 'approved':
                ins = "Your timesheets are now approved!"
                rec.instructions = txt % (ins)
            elif rec.state == 'reject':
                ins = "Your timesheets are rejected, you can check the comments under the approval details, please talk to your line manager for further queries."
                rec.instructions = txt % (ins)

    def calculate_weekly_allowances(self):
        employee = self.employee_id
        localdict = {
            **{
                'employee': employee,
            }
        }
        for allowance in self.allowances_ids:
            if allowance.filled:
                allowance.compute_rule(localdict)

    def check_substitution_claim(self):
        # substitution_id = self.substitution_rule_id
        # if not substitution_id:
        #     return False
        claimed = self.substitution_days or self.substitution_grade_id or self.substitution_team_id
        check = [self.substitution_days, self.substitution_grade_id, self.substitution_team_id]
        if not claimed:
            return False
        # if self.substitution_days >= 4:
        #     self.applicable_overtime_rule_id = claimed.rank.overtime_rule_id.id
        self.env['timesheet.submission.allowances.erpify'].create({
            'name': substitution_id.id,
            'days': self.substitution_days,
            'team_code': self.substitution_team_id.id,
            'rank': self.substitution_grade_id.id,
            'submission_request_id': self.id,
            'employee_id': self.employee_id.id,
        })

    @api.depends('timesheet_ids.unit_amount', 'time_in_lieu', 'start_date', 'end_date', 'employee_id',
                 'allowances_ids.hours')
    def _compute_all_amounts(self):
        for rec in self:
            normal_hours = rec.timesheet_ids.filtered(lambda r: r.type_id_erpify.select_by_default)
            allowance_amount = rec.allowances_ids.mapped('amount')
            rec.normal_total = (
                        sum(normal_hours.mapped('unit_amount')) * rec.employee_id.timesheet_cost) if normal_hours else 0
            rec.allowance_total = (sum(allowance_amount)) if allowance_amount else 0
            rec.total_amount = rec.normal_total + rec.allowance_total

    @api.constrains('time_in_lieu')
    def check_time_in_lieu(self):
        if self.time_in_lieu > 100 or self.time_in_lieu < 0:
            raise ValidationError('You have entered a wrong value for time in lieu, it should be in between 0 to 100 %')

    @api.depends('employee_id', 'start_date', 'end_date')
    def _get_record_name(self):
        for r in self:
            r.name = r.employee_id.name + ': ' + r.start_date.strftime("%d/%m/%Y") + ' to ' + r.end_date.strftime(
                "%d/%m/%Y")

    @api.constrains('start_date', 'end_date')
    def _onchange_start_date_or_end_date(self):
        if self.start_date and self.end_date:
            if self.end_date < self.start_date:
                raise ValidationError(_('The end date should be greater than the starting date.'))
            if self.timesheet_period == '1' and self.start_date and self.end_date:
                start = self.start_date.weekday()
                end = self.end_date.weekday()
                if (start and start != 0) or (end and end != 6):
                    raise ValidationError('Your week duration should start from Monday to Sunday.')
                duration = (self.end_date - self.start_date).days
                if duration != 6:
                    raise ValidationError('A week cannot be of more or less than 7 days.')

    @api.onchange('start_date', 'end_date')
    def _onchange_week_start_and_end_dates(self):
        for rec in self:
            today = self.start_date
            if rec.timesheet_period == '1':
                current_weekday = today.weekday()
                rec.start_date = today - timedelta(days=current_weekday)
                rec.end_date = today + timedelta(days=6 - current_weekday)
            else:
                last = calendar.monthrange(today.year, today.month)[1]
                rec.start_date = today.replace(day=1)
                rec.end_date = today.replace(day=last)

    def fetch_timesheets(self):
        if self.start_date and self.end_date and self.employee_id:
            vals = []
            subsistence_vals = []
            schedule = False
            if self.substitution_days > 0:
                max_substitution_days = self.employee_id.get_parameter_value_by_code('MAXSUBSDAYS')
                if self.substitution_days > max_substitution_days:
                    raise ValidationError('Your grade do not allow to claim more than %s days for substitution.' % str(
                        max_substitution_days))
            # grade = self.substitution_grade_id if self.substitution_grade_id and self.substitution_days >= 4 else self.pay_scale_id
            # if grade.schedule_ids:
            #     iterable = grade.schedule_ids
            #     schedule = True
            else:
                iterable = range(0, 7)
            for i, j in enumerate(iterable):
                vals.append((0, 0, {
                    'dairy_date': self.start_date + timedelta(days=i),
                    'work_type': 'ord',
                    'submission_id': self.id,
                    's0to8': 0 if not schedule else j.s0to8,
                    's8to20': 0 if not schedule else j.s8to20,
                    's20to24': 0 if not schedule else j.s20to24,
                }))
                subsistence_vals.append((0, 0, {'date': self.start_date + timedelta(days=i),
                                                'timesheet_submission_id': self.id, }))
                vals.append((0, 0, {
                    'dairy_date': self.start_date + timedelta(days=i),
                    'work_type': 'ot',
                    'submission_id': self.id,
                }))
            self.write({'dairy_time_ids': vals,
                        'subsistence_ids': subsistence_vals})

            timesheets = self.env['account.analytic.line'].search(
                [('employee_id', '=', self.employee_id.id), ('date', '>=', self.start_date),
                 ('date', '<=', self.end_date), ('timesheet_submission_erpify_id', 'in', [False, self.id]),
                 ('project_id', '=', self.employee_id.project_id_erpify.id)]).ids
            if timesheets:
                self.timesheet_ids = [(6, 0, timesheets)]

            all_categ = self.env['timesheet.allowances.category.erpify'].search(
                [('type', '=', 'allowance'), ('is_substitution', '=', False)])
            if self.allowances_ids:
                added_allowance_ids = self.allowances_ids.mapped('name.id')
            else:
                added_allowance_ids = []

            for categ in all_categ:
                t = self.timesheet_ids.filtered(lambda r: r.type_id_erpify.id == categ.id)
                if self.pay_scale_id.id not in categ.applicable_to_ids.ids:
                    continue
                if not self.employee_id.get_parameter_value_by_timecode(categ):
                    continue
                if t:
                    t_sum = sum(t.mapped('calc_hours'))
                else:
                    t_sum = 0
                if categ.id not in added_allowance_ids:
                    self.env['timesheet.submission.allowances.erpify'].create({
                        'name': categ.id,
                        'hours': t_sum,
                        'submission_request_id': self.id,
                        'employee_id': self.employee_id.id,
                        # 'hours_after_TIL': t_sum - (t_sum * self.time_in_lieu / 100),
                    })
            self.state = 'time'
            # self.check_and_get_leaves()
            # self.process_leaves_for_hourly_employees()

    def cancel(self):
        self.state = 'cancel'
        self.timesheet_ids = [(5)]

    def approve_reject(self):
        if self.env.user not in [self.sudo().manager_id.user_id, self.sudo().manager_id.user_id,
                                 self.sudo().manager_id.parent_id.user_id if self.sudo().manager_id.parent_id else False]:
            raise ValidationError('You cannot approve or reject this request, only the line manager or his manager  can do it.')
        if self.env.user.id == self.sudo().manager_id.user_id.id and self.env.user.id == self.sudo().employee_id.user_id.id and self.sudo().manager_id.parent_id:
            raise ValidationError(
                'You cannot approve or reject your own request, please ask %s to approve it.' % self.sudo().manager_id.parent_id.name)
        allowances = []
        appropriations = []
        subsistence = []
        for alw in self.allowances_ids:
            if alw.filled:
                allowances.append((0, 0, {'name': alw.name.id}))
        for appr in self.appropriation_ids:
            appropriations.append(
                (0, 0, {'ord_hrs': appr.ord_hrs, 'app_code': appr.app_code.id, 'ot_hrs': appr.ot_hrs}))
        for subs in self.subsistence_ids:
            if subs.where:
                subsistence.append(
                    (0, 0, {'type': subs.type, 'how': subs.how, 'where': subs.where, 'distance': subs.distance,
                            'dayofweek': subs.dayofweek, 'from_time': subs.time_depart, 'to_time': subs.time_return}))
        return {
            'name': _('Approve or Reject the timesheets'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'popup.wizard.timesheet',
            'target': 'new',
            'context': dict(
                default_user_id=self.env.user.id,
                default_timesheet_submission_id=self.id,
                default_claimed_allowance_ids=allowances,
                default_claimed_subsistence_ids=subsistence,
                default_appropriation_ids=appropriations,
                default_ot_hours=self.total_ot_hours,
                default_ordinary_hours=self.total_ord_hours,
            ),
        }

    def submit_request(self):
        if not self.env.context.get('added_by_web_erpify', False):
            self.validate_appr_hours()
        self.submission_date = datetime.now()
        message = 'Please approve the timesheets of ' + self.employee_id.display_name
        if not self.sudo().manager_id:
            to_notify = self.sudo().manager_id
        elif self.sudo().manager_id and self.sudo().manager_id != self.sudo().employee_id:
            to_notify = self.sudo().manager_id
        else:
            if self.sudo().manager_id.parent_id:
                to_notify = self.sudo().manager_id.parent_id
            else:
                to_notify = self.sudo().manager_id

        # if not to_notify:
        #     raise ValidationError(
        #         'Your employee profile does not show any manager details to submit this timesheet. Please contact HR team if you think it is a mistake.')
        # if not to_notify.sudo().user_id:
        #     raise ValidationError(
        #         "Your manager's profile is not linked with any user in the system so we cannot forward your timesheet to him. Please contact HR team.")
        # self.activity_schedule('mail.mail_activity_data_todo', note=message, user_id=to_notify.sudo().user_id.id)
        self.state = 'submit'
        self.check_eligibility_for_allowances()

    def check_eligibility_for_allowances(self):
        contradictory_rules = self.allowances_ids.filtered(lambda r: r.name.cant_be_with and r.filled)
        for c_rule in contradictory_rules:
            found = self.allowances_ids.filtered(lambda r: r.name.id == c_rule.name.cant_be_with.id and r.filled)
            if found.type == 'nda':
                found.sudo().unlink()
            else:
                raise ValidationError(
                    'You cannot claim %s and %s together. Please claim only one of these and try again.' % (
                    c_rule.name.name, found.name.name))


class ApprovalMatrixTimesheet(models.Model):
    _name = 'timesheet.approval.matrix'
    _description = 'Timesheet Approval Matrix'

    user_id = fields.Many2one('res.users', 'Approver')
    checked_at = fields.Datetime()
    status = fields.Selection([('approve', 'Approved'), ('reject', 'Rejected')], default='approve')
    comments = fields.Text()
    timesheet_submission_id = fields.Many2one('timesheet.submission.erpify')


class Wizard(models.TransientModel):
    _name = 'popup.wizard.timesheet'

    comments = fields.Text('Comments')
    user_id = fields.Many2one('res.users')
    timesheet_submission_id = fields.Many2one('timesheet.submission.erpify')
    claimed_allowance_ids = fields.One2many('claimed.allowance.wiz', 'wiz_id')
    claimed_subsistence_ids = fields.One2many('claimed.subsistence.wiz', 'wiz_id')
    appropriation_ids = fields.One2many('added.appropriations.wiz', 'wiz_id')
    til = fields.Float('Time in Lieu')
    ordinary_hours = fields.Float()
    ot_hours = fields.Float('Overtime Hours')
    total_hours = fields.Float(compute='get_total_hours')
    status = fields.Selection([('approve', 'Approve'), ('reject', 'Reject')], string='Action to Perform?')
    late = fields.Float('Late')

    @api.depends('ordinary_hours', 'ot_hours')
    def get_total_hours(self):
        for rec in self:
            rec.total_hours = rec.ordinary_hours + rec.ot_hours

    def proceed(self):
        self.timesheet_submission_id.approval_matrix.create({
            'user_id': self.user_id.id,
            'checked_at': datetime.now(),
            'status': self.status,
            'comments': self.comments,
            'timesheet_submission_id': self.timesheet_submission_id.id,
        })
        if self.status == 'approve':
            pending = self.timesheet_submission_id.sudo().employee_id.slip_ids.filtered(
                lambda r: r.state in ['draft', 'verify'])

            if self.late > 0:
                late_rules = self.env['timesheet.allowances.category.erpify'].search([('type', '=', 'late')])
                applicable_rate_rule = late_rules.filtered(
                    lambda r: self.timesheet_submission_id.pay_scale_id.id in r.applicable_to_ids.ids)
                if not applicable_rate_rule:
                    raise ValidationError(
                        'No late rule found for Pay-Scale: %s' % self.timesheet_submission_id.pay_scale_id.name)
                if applicable_rate_rule:
                    late_id = self.env['timesheet.submission.allowances.erpify'].create({
                        'name': applicable_rate_rule.id,
                        'hours': self.late,
                        'submission_request_id': self.timesheet_submission_id.id,
                        'employee_id': self.timesheet_submission_id.sudo().employee_id.id,
                    })
                    late_id.amount = late_id.calculate_late()
            self.timesheet_submission_id.sudo().activity_feedback(
                ['mail.mail_activity_data_todo'])

            if pending and (
                    self.env.user.company_id.lock_transaction_erpify or self.timesheet_submission_id.sudo().employee_id.company_id.lock_transaction_erpify):
                self.timesheet_submission_id.state = 'schd_approved'
            else:
                self.timesheet_submission_id.state = 'approved'
        else:
            self.timesheet_submission_id.sudo().activity_feedback(
                ['mail.mail_activity_data_todo'])
            self.timesheet_submission_id.state = 'reject'


class ClaimAlwWizard(models.TransientModel):
    _name = 'claimed.allowance.wiz'

    name = fields.Many2one('timesheet.allowances.category.erpify')
    wiz_id = fields.Many2one('popup.wizard.timesheet')


class AddedAppropriations(models.TransientModel):
    _name = 'added.appropriations.wiz'

    ord_hrs = fields.Float('Ord Hours')
    ot_hrs = fields.Float('O/T Hours')
    app_code = fields.Many2one('appropriation.code', 'Appropriation Code')
    wiz_id = fields.Many2one('popup.wizard.timesheet')


class ClaimedSubWiz(models.TransientModel):
    _name = 'claimed.subsistence.wiz'

    wiz_id = fields.Many2one('popup.wizard.timesheet')
    type = fields.Selection([('day', 'Day'), ('unight', 'Night'), ('extra', 'Extra'), ('weekly', 'Weekly')])
    from_time = fields.Float('Departed')
    to_time = fields.Float('Returned')
    dayofweek = fields.Selection([
        ('0', 'Monday'),
        ('1', 'Tuesday'),
        ('2', 'Wednesday'),
        ('3', 'Thursday'),
        ('4', 'Friday'),
        ('5', 'Saturday'),
        ('6', 'Sunday')
    ], 'Day of Week')
    how = fields.Char('How time was spent?')
    where = fields.Char('Where time was spent?')
    distance = fields.Float('Distance (km)')


class TimesheetProject(models.Model):
    _inherit = 'project.project'

    start_end_mand = fields.Boolean('Is Start and End time Mandatory?', default=True)
