from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class TimeInLieu(models.Model):
    _inherit = 'timesheet.submission.erpify'

    time_in_lieu = fields.Integer('Time in Lieu', default=0)
    time_in_lieu_hrs = fields.Float('Time in Lieu Hours (Claimed)', compute='get_claimed_time_in_lieu_hrs')

    @api.depends('time_in_lieu')
    def get_claimed_time_in_lieu_hrs(self):
        for rec in self:
            rec.time_in_lieu_hrs = rec.total_ot_hours / rec.time_in_lieu