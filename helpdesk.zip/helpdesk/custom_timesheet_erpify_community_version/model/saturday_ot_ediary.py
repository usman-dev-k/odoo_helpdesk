from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from odoo.tools import float_compare


class SaturdayOTeDiary(models.Model):
    _name = 'timesheet.saturday.ot.erpify'
    _description = 'eDiary Saturday OT'

    submission_id = fields.Many2one('timesheet.submission.erpify')
    weekly_view_id = fields.Many2one('timesheet.weekly.view.erpify')
    s0to8 = fields.Float('00:00 to 08:00')
    s8to13 = fields.Float('08:00 to 13:00')
    s13to20 = fields.Float('13:00 to 20:00')
    s20to24 = fields.Float('20:00 to 24:00')

    @api.model
    def create(self, vals_list):
        res = super(SaturdayOTeDiary, self).create(vals_list)
        res.weekly_view_id.sat_ot_id = res.id
        res.weekly_view_id.s0to8 = res.s0to8
        res.weekly_view_id.s20to24 = res.s20to24
        res.weekly_view_id.s8to13 = res.s8to13
        res.weekly_view_id.s13to20 = res.s13to20
        return res

    @api.constrains('s0to8', 's8to13', 's13to20', 's20to24')
    def validate_time_entered(self):
        for rec in self:
            if rec.s0to8 and float_compare(rec.s0to8, 8.0, precision_digits=2) > 0:
                raise UserError('You cannot enter more than 8 hours in 0:00 to 8:00 slot.')
            if rec.s20to24 and float_compare(rec.s20to24, 4.0, precision_digits=2) > 0:
                raise UserError('You cannot enter more than 4 hours in 20:00 to 24:00 slot.')
            if rec.s8to13 and float_compare(rec.s8to13, 5.0, precision_digits=2) > 0:
                raise UserError('You cannot enter more than 5 hours in 8:00 to 13:00 slot.')
            if rec.s13to20 and float_compare(rec.s13to20, 7.0, precision_digits=2) > 0:
                raise UserError('You cannot enter more than 7 hours in 13:00 to 20:00 slot.')

