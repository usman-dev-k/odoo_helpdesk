# -*- coding: utf-8 -*-

{
    "name": "Enterprise Backend Theme V13",
    "summary": "Enterprise Backend Theme V13",
    "version": "13.0.0.3",
    "category": "Theme/Backend",
    "website": "http://www.odoo.net",
	"description": """
		Enterprise Backend theme for Odoo 13.0 community edition.
    """,
	'images':[
        'images/screen.png'
	],
    "author": "Usman Khalid",
    "installable": True,
    "depends": [
        'web',
        'web_responsive',

    ],
    "data": [
        'views/assets.xml',
		'views/res_company_view.xml',
		'views/users.xml',
        	'views/sidebar.xml',
    ],

}

