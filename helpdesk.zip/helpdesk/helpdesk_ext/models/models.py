# -*- coding: utf-8 -*-

from odoo import models, fields, api
import base64
from jinja2 import Environment, BaseLoader


class helpdesk_ext(models.Model):
    _inherit ='helpdesk.team'
    _description = 'helpdesk_ext.helpdesk_ext'

    sender_email = fields.Char(string="Sender Alias")


class helpdesk_ticket_ext(models.Model):
    _inherit = 'helpdesk.ticket'


    @api.model
    def create(self, vals):
        new_rec = super(helpdesk_ticket_ext, self).create(vals)
        # if new_rec.create_uid.id == 1:
        if new_rec.partner_id.email:
            sender= new_rec.partner_id.email.split()
            sender = new_rec.partner_id.email.split('@')
            sender = sender[1]
            email_alias = self.env['helpdesk.team'].search([('sender_email','=',sender)])
            new_rec.team_id = email_alias
            
        new_rec.send_email_client()
        # if new_rec.create_uid.id == 2:
        #     if new_rec.partner_id.email:
        #         print("levelk3")
        #         sender= new_rec.partner_id.email.split()
        #         sender = new_rec.partner_id.email.split('@')
        #         sender = sender[1]
        #         print("level4")
        #         print(sender)
        #         print("level4")
        #         email_alias = self.env['helpdesk.team'].search([('sender_email','=',sender)])
        #         print("level5")
        #         print(email_alias)
        #         print("level5")
        #         new_rec.team_id = email_alias
        #     new_rec.send_email_client()
        return new_rec

    def send_email_client(self):
        self.ensure_one()
        for desk in self:
            if desk.team_id:
                if desk.team_id.member_ids:
                    emails_data =""

                    for x in desk.team_id.member_ids:
                        for y in x.partner_id:
                            if y.email:
                                emails_data += y.email+","
                                print(emails_data)
                    mail_obj = self.env['mail.mail']

                    send_to =emails_data
                    team_member = ""
                    if desk.team_id.member_ids:
                        for x in desk.team_id.member_ids:
                            team_member += x.name+", "
                    ticket_number = []
                    if desk.name:
                        ticket_name = desk.name
                        ticket_number.append(ticket_name)
                        
                    form_design = """
                        <b>Dear Team Member</b>
                        {%for team in team_member%}
                            <span>{{team.name}}</span>
                        {%endfor%}
                        <br/>
                        The Ticket Number Is Assigned To You
                        {%for tickect in ticket_number%}
                            <span style="font-weight:bold">{{tickect}}</span>
                        {%endfor%}
                        <br/>
                        <br/>
                        Do not hesitate to contact us if you have any questions.
                        <br/>
                        <br/>
                        <b>Regards:</b>
                    """
                        # <img class="img-fluid o_we_custom_image float-left" src="https://rawnaqbucket.s3.amazonaws.com/odoo/ed6ebd0245c483dd4873c5c4b6aa90554dd23cc7?access_token=8ec71a00-054b-43b9-9d79-e283f4930237" style="width: 50%;">

                    email_from = self.env['ir.mail_server'].search([],limit=1)
                    template = Environment(loader=BaseLoader).from_string(form_design)
                    template_vars = {"ticket_number":ticket_number,"team_member":team_member}
                    html_out = template.render(template_vars)
                    my_mail =  mail_obj.create({
                    'email_from': email_from.smtp_user,
                    'email_to': send_to,
                    'subject': "Help Desk-",
                    'body_html':
                    '''<span  style="font-size: 14px"><br/>
                      <br/>%s </span> 
                      <br/><br/>''' % (html_out)}).send()

    # def get_team_member(self):
    #     team_member = ""
    #     if self.team_id.member_ids:
    #         for x in self.team_id.member_ids:
    #             team_member += x.name+", "
    #     return team_member
