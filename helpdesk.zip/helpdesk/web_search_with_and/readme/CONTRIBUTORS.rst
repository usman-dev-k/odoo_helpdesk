* Andrius Preimantas <andrius@versada.lt>
* Adrien Didenot <adrien.didenot@horanet.com>
* Francesco Apruzzese <f.apruzzese@apuliasoftware.it>
* Numigi (tm) and all its contributors (https://bit.ly/numigiens)
* Souheil Bejaoui <souheil.bejaoui@acsone.eu>
