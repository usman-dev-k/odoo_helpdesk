# -*- coding: utf-8 -*-

from odoo import models, fields, api


class attendance_ext(models.Model):
    _inherit = 'hr.attendance'
    
    description = fields.Text(string="Description")