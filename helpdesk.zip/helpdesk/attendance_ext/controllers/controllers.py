# -*- coding: utf-8 -*-
# from odoo import http


# class AttendanceExt(http.Controller):
#     @http.route('/attendance_ext/attendance_ext/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/attendance_ext/attendance_ext/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('attendance_ext.listing', {
#             'root': '/attendance_ext/attendance_ext',
#             'objects': http.request.env['attendance_ext.attendance_ext'].search([]),
#         })

#     @http.route('/attendance_ext/attendance_ext/objects/<model("attendance_ext.attendance_ext"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('attendance_ext.object', {
#             'object': obj
#         })
