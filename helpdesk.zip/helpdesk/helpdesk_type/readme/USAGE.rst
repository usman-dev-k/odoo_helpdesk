* Go to Helpdesk
* Create a ticket and set its type.
