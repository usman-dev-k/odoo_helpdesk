{
    'name' : 'Helpdesk Management Extended',
    'summary' : '',
    'description' : '',
    'author' : 'ERPify',
    'license': "AGPL-3",
    'website': "",
    'category': '',
    'version': '13.0',
    'data': ['security/security.xml', 'views/views.xml'],
    'depends': ['base', 'helpdesk_mgmt'],
    'installable': True,
    'application': False,
    'auto_install': False,

}
