from odoo import models, fields


class Users(models.Model):
    _inherit = 'res.users'

    def get_helpdesk_team_members(self):
        teams = self.helpdesk_team_ids
        partner_ids = []
        for team in teams:
            for user in team.user_ids:
                partner_ids.append(user.partner_id.id)
        return partner_ids

    def _get_partner_private_employee(self):
        domain = ['|', ('type', '!=', 'private'), ('type', '=', False)]

        if self.env.user.has_group('helpdesk_mgmt.group_helpdesk_team_manager'):
            _domain = ['&', ('id', 'in', self.get_helpdesk_team_members())] + domain
            domain = _domain

        partners = self.env['res.partner'].search(domain)
        if not partners:
            return []

        return partners.ids


class ResPartner(models.Model):
    _inherit = 'res.partner'

    helpdesk_team_ids = fields.Many2many(comodel_name="helpdesk.ticket.team", relation="helpdesk_team_partner_rel",
                                         column1="helpdesk_partner_id", column2="helpdesk_id",
                                         string="Helpdesk Team")
