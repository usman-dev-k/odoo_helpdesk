# -*- coding: utf-8 -*-
{
    'name': 'Generate or transform content with AI in Html Field Editor',
    'description': 'Generate or transform content with AI in Html Field Editor',
    'category': 'Extra Tools or Productivity',
    'summary': 'Generate or transform content with AI in Html Field Editor',
    'sequence': 10,
    'version': '13.0.1',
    'website': 'https://www.odoo.net',
    'author': 'Usman Khalid',
    'depends': ['web_editor'],
    'data': [
        'views/assets.xml',
    ],
    'application': True,
    'license': 'AGPL-3',
}