import json
import logging
from odoo.http import request, Response
from odoo import http, tools, _, SUPERUSER_ID, release
from odoo.exceptions import UserError, MissingError, AccessError
from odoo.addons.ai_html_widget.tools import iap_tools
_logger = logging.getLogger(__name__)

DEFAULT_OLG_ENDPOINT = 'https://olg.api.odoo.com'

class Web_Editor_EXT(http.Controller):

	@http.route("/web_editor/generate_text", type="json", auth="user")
	def generate_text(self, prompt, conversation_history):
		try:
			IrConfigParameter = request.env['ir.config_parameter'].sudo()
			olg_api_endpoint = IrConfigParameter.get_param('web_editor.olg_api_endpoint', DEFAULT_OLG_ENDPOINT)
			response = iap_tools.iap_jsonrpc(olg_api_endpoint + "/api/olg/1/chat", params={
				'prompt': prompt,
				'conversation_history': conversation_history or [],
				'version': release.version,
			}, timeout=30)
			if response:
				if response['status'] == 'success':
					return response['content']
				elif response['status'] == 'error_prompt_too_long':
					raise UserError(_("Sorry, your prompt is too long. Try to say it in fewer words."))
				else:
					raise UserError(_("Sorry, we could not generate a response. Please try again later."))
			else:
				raise AccessError(_("Oops, it looks like our AI is unreachable!"))
		except AccessError:
			raise AccessError(_("Oops, it looks like our AI is unreachable!"))