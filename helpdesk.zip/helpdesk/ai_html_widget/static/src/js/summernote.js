odoo.define('ai_html_widget.summernote', function(require) {
    'use strict';
    var core = require('web.core');
    require('web_editor.wysiwyg');
    var handler = $.summernote.eventHandler;
    var lang = $.summernote.lang.odoo;
    var _t = core._t;
    var tmpl = $.summernote.renderer.getTemplate();
    const topBus = window.top.odoo.__DEBUG__.services['web.core'].bus;
    var summernoteManager = require('web_editor.rte.summernote');
    var weWidgets = require('wysiwyg.widgets');

    $.extend(lang, {
        AI: {
            AI: _t('Generate or transform content with AI')
        }
    })
    $.summernote.addPlugin({
        buttons: {
            "AI": function(lang, options) {
                var button = tmpl.iconButton(options.iconPrefix + 'reddit-alien', {
                    event: 'showAIDialog',
                    hide: true,
                    title: lang.AI.AI,
                });
                return button;
            },
        },
        events: {
            "showAIDialog": function(layoutInfo, value) {
                var dom = $.summernote.core.dom;
                var layoutInfoCustom = dom.makeLayoutInfo(layoutInfo.currentTarget);
                var $dialog = layoutInfoCustom.dialog(),
                    $editable = layoutInfoCustom.editable();
                var header = $dialog.find('.note-AI-dialog').find('.modal-header');
                header.find('.close').attr('aria-hidden', false);
                handler.invoke('editor.saveRange', $editable);
                this.AIDialog($editable, $dialog).then(function(data) {
                    handler.invoke('editor.restoreRange', $editable);
                }).fail(function() {
                    handler.invoke('editor.restoreRange', $editable);
                });
            },
            "AIDialog": function($editable, $dialog) {
                return $.Deferred(function(deferred) {
                    var $AIDialog = $dialog.find('.note-AI-dialog');
                    $AIDialog.one('shown.bs.modal', function() {}).one('hidden.bs.modal', function() {
                        if (deferred.state() === 'pending') {
                            deferred.reject();
                        }
                    }).modal('show');
                });
            },
        },
        dialogs: {
            AIDialog: function(lang, options) {
                var body =
                    `<div id="container"></div>`;
                var footer = '<button href="#" class="btn btn-primary note-AI-btn" disabled>' + 'Generate or transform content with AI' + '</button>';
                return tmpl.dialog('note-AI-dialog', 'Generate or transform content with AI', body, footer);
            }
        }
    });

    $.summernote.pluginEvents.showAIDialog = function(event, editor, layoutInfo, sorted) {
        var $editable = layoutInfo.editable();
        var $selection = layoutInfo.handle().find('.note-control-selection');
        topBus.trigger('AI_dialog_demand', {
            $editable: $editable,
            media: $selection.data('target'),
        });
    };
    summernoteManager.include({
        init: function(parent) {
            var res = this._super.apply(this, arguments);
            topBus.on('AI_dialog_demand', this, this._onAIDialogDemand);
            return res;
        },
        destroy: function() {
            topBus.off('AI_dialog_demand', this, this._onAIDialogDemand);
            return this._super.apply(this, arguments);
        },
        _onAIDialogDemand: function(data) {
            if (data.__alreadyDone) {
                return;
            }
            data.__alreadyDone = true;
            var AIDialog = new weWidgets.AIDialog(this,
                data.media,
                data.$editable,
            );
            AIDialog.open();
        },
    })
});