odoo.define('wysiwyg.widgets.AIDialog', function(require) {
    'use strict';

    var core = require('web.core');
    var Dialog = require('wysiwyg.widgets.Dialog');
    var _t = core._t;
    var Session = require('web.session');

    var AIDialog = Dialog.extend({
        template: 'wysiwyg.widget.AI',
        xmlDependencies: (Dialog.prototype.xmlDependencies || []).concat([
            '/ai_html_widget/static/src/xml/wysiwyg.xml'
        ]),
        events: {
            'click .o-message-insert': '_onClickInsert',
            'click .note-record-stop-btn-submit': '_onClickSubmit',
            'keyup #promptInput': '_onChangeTextArea',
            'keydown #promptInput': '_onTextareaKeydown',
        },

        /**
         * @constructor
         */
        init: function(parent, media, editable) {
            this._super(parent, _.extend({}, {
                title: _t("Generate or transform content with AI")
            }, {}));
            this.editable = editable;
        },
        start: function() {
            this.TextButton = this.$('button.note-record-stop-btn-submit').prop('disabled', true);
            this.$primaryButton = this.$footer.find('.btn-primary').remove();
            this.$secondaryButton = this.$footer.find('.btn-secondary').text('Close AI Chat');
            this.results_div = this.$('div.results_div');
            this.promptInput = this.$('textarea.promptInput');
            var selectedText = this._getSelectedText();
            this.promptInput.val(selectedText);
            if (this.promptInput.length != 0) {
                if (this.promptInput.val().length != 0) {
                    this.TextButton.addClass('btn-success')
                    this.TextButton.prop('disabled', false);
                } else {
                    this.TextButton.removeClass('btn-success')
                    this.TextButton.prop('disabled', true);
                }
            }
            var self = this;
        },
        _getSelectedText: function() {
            var selectedText = '';
            if (window.getSelection) {
                selectedText = window.getSelection().toString();
            } else if (document.selection && document.selection.type != 'Control') {
                selectedText = document.selection.createRange().text;
            }
            return selectedText;
        },
        _scrollResultsDiv: function() {
            var resultsDiv = this.$('.results_div');
            resultsDiv.scrollTop(resultsDiv.prop('scrollHeight'));
        },
        _onClickInsert: function(ev) {
            var targetElement = ev.currentTarget;
            var nextContentDiv = $(targetElement).next('.d-inline');
            if (nextContentDiv.length > 0) {
                var nextContent = nextContentDiv.html();
                var pTag = this.editable.find('p');
                if (pTag.length > 1) {
                    pTag.last().append(nextContent);
                } else {
                    pTag.append(nextContent);
                }
            } else {}
            this.close();
        },
        _onTextareaKeydown(ev) {
            if (ev.key === 'Enter' && !ev.shiftKey) {
                if (this.promptInput.val().length != 0) {
                    this._onClickSubmit(ev);
                    this.promptInput.val('');
                    this.TextButton.prop('disabled', true);
                } else {
                    ev.preventDefault();
                }
            }
            if (ev.keyCode == 13) {
                ev.preventDefault();
            }
        },
        _onChangeTextArea: function(ev) {
            if (ev.currentTarget.value.length != 0) {
                this.TextButton.addClass('btn-success')
                this.TextButton.prop('disabled', false);
            } else {
                this.TextButton.removeClass('btn-success')
                this.TextButton.prop('disabled', true);
            }
        },

        _generate(prompt, callback) {
            const protectedCallback = (...args) => {
                delete this.pendingRpcPromise;
                return callback(...args);
            }
            this.pendingRpcPromise = Session.rpc('/web_editor/generate_text', {
                prompt,
                conversation_history: [],
            }, { shadow: true });
            return this.pendingRpcPromise
                .then(content => protectedCallback(content))
                .catch(error => protectedCallback(_t(error.data ? .message || error.message), true));
        },

        _freezeInput() {
            this.promptInput.prop('disabled', true);
        },
        _unfreezeInput() {
            this.promptInput.prop('disabled', false);
            this.promptInput.focus();
        },

        _onClickSubmit: function(ev) {
            this._freezeInput();
            ev.preventDefault();
            const promptInput = this.promptInput.val()
            const response_div_id = _.uniqueId("response_div");
            let data_pre = `<div class="response_div" data-id=
            ${ response_div_id }
            >
                        <div class="position-relative d-flex flex-shrink-0">
                            <div class="d-flex flex-shrink-0" style="flex-basis: 42px; max-width: 42px;">
                                <div class="position-relative bg-view" style="width: 36px; height: 36px;"> <img class="w-100 h-100 rounded" src="/ai_html_widget/static/description/icon.png" /> </div>
                            </div>
                            <div class="w-100 o-min-width-0">
                                <div class="d-flex flex-wrap align-items-baseline mb-1 lh-1"> <strong class="me-1 text-truncate">You</strong> </div>
                                <div class="position-relative d-flex">
                                    <div class="o-min-width-0">
                                        <div class="position-relative d-flex">
                                            <div class="position-relative overflow-x-auto d-inline-block">
                                                <div class="position-relative text-break mb-0 py-2 px-3 align-self-start rounded-end-3 rounded-bottom-3 o-chatgpt-message" style="border-radius: 0px 5px 5px 10px; color: #373434; border: #000000; background: #c6e8ed;"> ${promptInput} </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="mt-4 mb-4 position-relative d-flex flex-shrink-0">
                            <div class="d-flex flex-shrink-0" style="flex-basis: 42px; max-width: 42px;">
                                <div class="position-relative bg-view" style="width: 36px; height: 36px;"> <img class="w-100 h-100 rounded" src="/ai_html_widget/static/description/bot.png" /> </div>
                            </div>
                            <div class="w-100 o-min-width-0">
                                <div class="d-flex flex-wrap align-items-baseline mb-1 lh-1"> <strong class="me-1 text-truncate">Bot</strong> </div>
                                <div class="position-relative d-flex">
                                    <div class="o-min-width-0">
                                        <div class="position-relative d-flex">
                                            <div class="position-relative text-break mb-0 py-2 px-3 align-self-start rounded-end-3 rounded-bottom-3 o-chatgpt-message" style="flex-direction: row; display: flex; justify-content: space-between; align-items: center; border: #000000; background: #b0ed94; border-radius: 0px 5px 5px 10px;"><img src="/ai_html_widget/static/description/spin.svg" alt="Loading..." class="me-2" style="filter:invert(1); opacity: 0.5; width: 30px; height: 30px;"/>
                                                <div class="d-inline">
                                                    <p style="padding-left:10px; margin:0px !important;">Thinking....</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>`;
            this.results_div.append(data_pre);
            this._scrollResultsDiv();

            this.TextButton.prop('disabled', true);
            this._generate(promptInput, (content, isError) => {
                var selectedDiv = this.results_div.find('.response_div[data-id="' + response_div_id + '"]');
                if (isError == false || isError === undefined || isError == null) {
                    let data = `<div class="response_div" data-id=
                    ${ response_div_id }
                    >
                    <div class="position-relative d-flex flex-shrink-0">
                        <div class="d-flex flex-shrink-0" style="flex-basis: 42px; max-width: 42px;">
                            <div class="position-relative bg-view" style="width: 36px; height: 36px;"> <img class="w-100 h-100 rounded" src="/ai_html_widget/static/description/icon.png" /> </div>
                        </div>
                        <div class="w-100 o-min-width-0">
                            <div class="d-flex flex-wrap align-items-baseline mb-1 lh-1"> <strong class="me-1 text-truncate">You</strong> </div>
                            <div class="position-relative d-flex">
                                <div class="o-min-width-0">
                                    <div class="position-relative d-flex">
                                        <div class="position-relative overflow-x-auto d-inline-block">
                                            <div class="position-relative text-break mb-0 py-2 px-3 align-self-start rounded-end-3 rounded-bottom-3 o-chatgpt-message" style="border-radius: 0px 5px 5px 10px; color: #373434; border: #000000; background: #c6e8ed;"> ${promptInput} </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mt-4 mb-4 position-relative d-flex flex-shrink-0">
                        <div class="d-flex flex-shrink-0" style="flex-basis: 42px; max-width: 42px;">
                            <div class="position-relative bg-view" style="width: 36px; height: 36px;"> <img class="w-100 h-100 rounded" src="/ai_html_widget/static/description/bot.png" /> </div>
                        </div>
                        <div class="w-100 o-min-width-0">
                            <div class="d-flex flex-wrap align-items-baseline mb-1 lh-1"> <strong class="me-1 text-truncate">Bot</strong> </div>
                            <div class="position-relative d-flex">
                                <div class="o-min-width-0">
                                    <div class="position-relative d-flex">
                                        <div class="position-relative text-break mb-0 py-2 px-3 align-self-start rounded-end-3 rounded-bottom-3 o-chatgpt-message" style="flex-direction: row-reverse; display: flex; justify-content: space-between; align-items: baseline; border: #000000; background: #b0ed94; border-radius: 0px 5px 5px 10px;"><button class="o-message-insert d-block float-end p-1 mb-1 btn btn-info opacity-75 fst-italic ms-3" style="min-width: 100px; margin-bottom: 0px !important; margin-left: 10px; font-style: italic; font-size: 12px; position: relative;">Click To Insert</button>
                                            <div class="d-inline">
                                                <p>${content}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`;
                    selectedDiv.replaceWith(data);
                    this._unfreezeInput();
                    this._scrollResultsDiv();

                } else {
                    let data = `<div class="response_div" data-id=
                    ${ response_div_id }
                    >
                        <div class="position-relative d-flex flex-shrink-0">
                            <div class="d-flex flex-shrink-0" style="flex-basis: 42px; max-width: 42px;">
                                <div class="position-relative bg-view" style="width: 36px; height: 36px;"> <img class="w-100 h-100 rounded" src="/ai_html_widget/static/description/icon.png" /> </div>
                            </div>
                            <div class="w-100 o-min-width-0">
                                <div class="d-flex flex-wrap align-items-baseline mb-1 lh-1"> <strong class="me-1 text-truncate">You</strong> </div>
                                <div class="position-relative d-flex">
                                    <div class="o-min-width-0">
                                        <div class="position-relative d-flex">
                                            <div class="position-relative overflow-x-auto d-inline-block">
                                                <div class="position-relative text-break mb-0 py-2 px-3 align-self-start rounded-end-3 rounded-bottom-3 o-chatgpt-message" style="border-radius: 0px 5px 5px 10px; color: #373434; border: #000000; background: #c6e8ed;"> ${promptInput} </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="mt-4 mb-4 position-relative d-flex flex-shrink-0">
                            <div class="d-flex flex-shrink-0" style="flex-basis: 42px; max-width: 42px;">
                                <div class="position-relative bg-view" style="width: 36px; height: 36px;"> <img class="w-100 h-100 rounded" src="/ai_html_widget/static/description/bot.png" /> </div>
                            </div>
                            <div class="w-100 o-min-width-0">
                                <div class="d-flex flex-wrap align-items-baseline mb-1 lh-1"> <strong class="me-1 text-truncate">Bot</strong> </div>
                                <div class="position-relative d-flex">
                                    <div class="o-min-width-0">
                                        <div class="position-relative d-flex">
                                            <div class="position-relative text-break mb-0 py-2 px-3 align-self-start rounded-end-3 rounded-bottom-3 o-chatgpt-message" style="flex-direction: row-reverse; display: flex; justify-content: space-between; align-items: baseline; border: #000000; color:#393939;background: #ff758c; border-radius: 0px 5px 5px 10px;">
                                                <div class="d-inline">
                                                    <p>Sorry, we could not generate a response. Please try again later.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>`;
                    selectedDiv.replaceWith(data);
                    this._unfreezeInput();
                    this._scrollResultsDiv();

                }
            });
            this.promptInput.val('');
        },
    });
    return AIDialog;
});