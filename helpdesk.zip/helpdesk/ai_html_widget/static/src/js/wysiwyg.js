odoo.define('ai_html_widget.wysiwyg', function (require) {
  'use strict';

  var wysiwyg = require('web_editor.wysiwyg');
  var weWidgets = require('wysiwyg.widgets');
  var AIDialog = require('wysiwyg.widgets.AIDialog');
  $.extend(weWidgets, {AIDialog: AIDialog});
  wysiwyg.extend({
    defaultOptions: wysiwyg.prototype.defaultOptions.toolbar.push([
      'AI', ['AI']
    ])
  })
});

