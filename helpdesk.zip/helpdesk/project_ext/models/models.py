# -*- coding: utf-8 -*-

from odoo import models, fields, api
import base64
from jinja2 import Environment, BaseLoader


class Project(models.Model):
    _inherit = 'project.project'


    customer_id = fields.Many2one('res.partner', 'Customers', track_visibility='onchange')
    contact_id = fields.Many2one('res.partner','Point of Contact', track_visibility='onchange')
    labels_ids = fields.Many2many('label.label', string='Labels', track_visibility='onchange')
    functional_team_ids = fields.Many2many('hr.employee', string='Functional Team', track_visibility='onchange')
    planned_start_date = fields.Date(string='Planned Start Date', widget='date', track_visibility='onchange')
    planned_end_date = fields.Date(string='Planned End Date', widget='date', track_visibility='onchange')
    start_date = fields.Date('Start Date', track_visibility='onchange')
    end_date = fields.Date('End Date', track_visibility='onchange')
    tech_team_ids = fields.Many2many('hr.employee', string='Tech Team', relation='project_tech_team_rel', track_visibility='onchange')
    allocatedhours = fields.Float('Allocated Hours', track_visibility='onchange')
    go_live_date = fields.Date('Go Live Date', track_visibility='onchange')
    dev_hours = fields.Float('Development Hours', track_visibility='onchange')
    timesheet_ids = fields.One2many('project.timesheets', 'projects_id', string='Timesheet', track_visibility='onchange')
    description = fields.Text('Description', track_visibility='onchange')

    @api.onchange('customer_id')
    def onchange_customer(self):
        if self.customer_id:
            self.contact_id = self.customer_id.child_ids
        else:
            self.contact_id = False

    @api.model
    def create(self, vals):
        """
        Else the menu will be still hidden even after removing from the list
        """
        self.clear_caches()
        return super(Project, self).create(vals)

    def write(self, vals):
        """
        Else the menu will be still hidden even after removing from the list
        """
        res = super(Project, self).write(vals)
        self.clear_caches()
        return res


class Timesheet(models.Model):
    _name = 'project.timesheets'
    _rec_name = 'projects_id'

    projects_id = fields.Many2one('project.project', 'Project ID', track_visibility='onchange')
    date = fields.Date('Date', required=True, track_visibility='onchange')
    employee_id = fields.Many2one('hr.employee','Employee', required=True, track_visibility='onchange')
    name = fields.Char('Description', track_visibility='onchange')
    start = fields.Float('From', track_visibility='onchange')
    end = fields.Float('To', track_visibility='onchange')
    unit_amount = fields.Float('Duration(Hours)', compute='_compute_hours', store=True, track_visibility='onchange')

    @api.depends('start', 'end')
    def _compute_hours(self):
        for record in self:
            if record.start and record.end:
                # Calculate the hours based on the difference between 'to_time' and 'from_time'
                record.unit_amount = record.end - record.start
            else:
                record.unit_amount = 0.0

class Label(models.Model):
    _name = 'label.label'
    _description = 'Labels'
    _rec_name = 'name'

    name = fields.Char(string='Label Name', required=True, track_visibility='onchange')

class TechModel(models.Model):
    _name = 'tech.model'
    _description = 'Tech Skills'

    # name = fields.Char(string='Tech Skill')
    employee_ids = fields.Many2many('hr.employee', string='Employees')

class ResUsers(models.Model):
    _inherit = 'res.users'


    project_ids = fields.Many2many('project.project', string='Project', track_visibility='onchange')

    def get_project_ids(self):
        if self.project_ids:
            project_ids = self.env['project.project'].search([('id', 'in', self.project_ids.ids)]).ids
        else:
            project_ids = self.env['project.project'].search([('id', '!=',False)]).ids
        print(project_ids)
        print("project_ids =================================")
        return project_ids

    @api.model
    def create(self, vals):
        """
        Else the menu will be still hidden even after removing from the list
        """
        self.clear_caches()
        return super(ResUsers, self).create(vals)

    def write(self, vals):
        """
        Else the menu will be still hidden even after removing from the list
        """
        res = super(ResUsers, self).write(vals)
        self.clear_caches()
        return res

