# -*- coding: utf-8 -*-

{
    'name': 'Helpdesk Timesheets',
    'version': '13.0.0.1',
    'category': 'Operations/Helpdesk',
    'license': 'AGPL-3',
    'summary': 'Timesheets integrated with Helpdesk',
    'depends': ['helpdesk_mgmt', 'custom_timesheet_erpify_community_version'],
    'description': """Track timesheets from helpdesk ticket""",
    'data': [
        'views/helpdesk_views.xml', 'views/timesheet_views.xml',
    ],
    'author': 'ERPify Inc.',
    'company': 'ERPify Inc.',
    'website': "https://www.erpify.biz",
    'installable': True,
    'auto_install': False,
    'application': False,
}
