# -*- coding: utf-8 -*-

from odoo import fields, models


class TimeCode(models.Model):
    _inherit = 'timesheet.time.code'

    ticket_mandatory = fields.Boolean('Helpdesk Ticket Mandatory for Time Entry?')


class AccountAnalyticLine(models.Model):
    _inherit = 'account.analytic.line'

    helpdesk_ticket_id = fields.Many2one('helpdesk.ticket', 'Helpdesk Ticket')
    ticket_mandatory = fields.Boolean(related='time_code_id.ticket_mandatory')

