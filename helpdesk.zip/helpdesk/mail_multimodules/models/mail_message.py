# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import base64
import datetime
import logging
import psycopg2
import smtplib
import threading
import re

from collections import defaultdict

from odoo import _, api, fields, models
from odoo import tools
from odoo.addons.base.models.ir_mail_server import MailDeliveryException
from odoo.tools.safe_eval import safe_eval

_logger = logging.getLogger(__name__)






class MailMessage(models.Model):

	_inherit = "mail.message"


	@api.model_create_multi
	def create(self, values_list):

		print('it is getting')
		print('it is getting')

		server_resrv_1 = self.env['ir.mail_server'].sudo().search([] , limit=1)



		print(server_resrv_1)
		print(values_list)
		for vals in values_list:
			if vals:
				vals["mail_server_id"] = server_resrv_1.id
				vals["email_from"] = '"Company" <{0}>'.format(str(server_resrv_1.smtp_user))
				vals["reply_to"] = '"Company" <{0}>'.format(str(server_resrv_1.smtp_user))

		print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
		print(vals)
		print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
		return super(MailMessage, self).create(vals)