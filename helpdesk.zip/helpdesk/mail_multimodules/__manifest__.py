# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).
{
    "name": "Email Gateway Multi Modules Wise",
    "version": "13.0.0.1.0",
    "category": "Extra Tools",
    "author": "Usman Khalid",
    "website": "https://odoo.net",
    "license": "AGPL-3",
    "depends": ["mail"],
    "installable": True,
}
