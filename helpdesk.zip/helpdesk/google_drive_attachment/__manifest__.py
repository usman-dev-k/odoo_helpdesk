# -*- coding: utf-8 -*-


{
    'name': "Attachments Upload on Google Drive",
    'summary': """
        Upload attachments on google drive.
        """,
    'description': """
        Upload your attachment file on google drive and get download link
    """,
    'author': 'UsSMAN KHALID',
    'support': 'https://contact.fyi/rylctcvsju',
    'website': 'https://contact.fyi/rylctcvsju',

    'version': '15.0.10.0',
    "price": 0,
    "currency": 'USD',
    'license': 'OPL-1',

    'depends': ['base','base_setup'],
    
    'data': [
        'security/ir.model.access.csv',
        'views/multi_folder_drive_view.xml',
        'views/res_config_view.xml'
    ],
    'installable': True,
    'auto_install': False,
}
