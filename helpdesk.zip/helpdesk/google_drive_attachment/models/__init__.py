# -*- coding: utf-8 -*-
# Part of Laxicon Solution. See LICENSE file for full copyright and
# licensing details.

from . import res_config
from . import google_file_upload
# from . import res_company
from . import multi_folder_drive
from . import ir_attachment
from . import custom_google_drive_configure