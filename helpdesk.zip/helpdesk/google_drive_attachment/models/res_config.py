# -*- coding: utf-8 -*-


from ast import literal_eval
from odoo import api, fields, models, _

class ResConfigSettings(models.TransientModel):

	_inherit = "res.config.settings"

	drive_folder_id = fields.Char(readonly=False,
								  help="make a folder on drive in which you want to upload files; then open that folder; the last thing in present url will be folder id")

	folder_type = fields.Selection([('single_folder', 'Single Folder'),
									('multi_folder', 'Multi Folder'),
									('record_wise_folder', 'Record wise Folder')], default='single_folder',readonly=False)

	model_ids = fields.Many2many(
		'ir.model',readonly=False, string="Models")



	def set_values(self):
		res = super(ResConfigSettings, self).set_values()

		params_obj = self.env['ir.config_parameter']
		params_obj.sudo().set_param("google_drive_attachment.drive_folder_id", self.drive_folder_id)
		params_obj.sudo().set_param("google_drive_attachment.folder_type", self.folder_type)
		params_obj.sudo().set_param("google_drive_attachment.model_ids", self.model_ids.ids)

		return res



	@api.model
	def get_values(self):

		res = super(ResConfigSettings, self).get_values()
		c_model_ids = self.env['ir.config_parameter'].sudo().get_param('google_drive_attachment.model_ids')


		if c_model_ids:

			res.update(	
				drive_folder_id=self.env['ir.config_parameter'].sudo().get_param('google_drive_attachment.drive_folder_id'),
				folder_type=self.env['ir.config_parameter'].sudo().get_param('google_drive_attachment.folder_type'),
				model_ids=[(6, 0, literal_eval(c_model_ids))]
			)

		else:


			res.update(	
				drive_folder_id=self.env['ir.config_parameter'].sudo().get_param('google_drive_attachment.drive_folder_id'),
				folder_type=self.env['ir.config_parameter'].sudo().get_param('google_drive_attachment.folder_type'),
				model_ids=[(6, 0, [])]
			)


		return res