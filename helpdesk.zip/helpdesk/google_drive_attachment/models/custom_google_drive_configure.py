from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
import odoo
from odoo.service import db
from odoo.http import request

from werkzeug import urls
from datetime import timedelta

import datetime
import os
import json
import requests
import logging

_logger = logging.getLogger(__name__)

GOOGLE_AUTH_ENDPOINT = 'https://accounts.google.com/o/oauth2/auth'
GOOGLE_TOKEN_ENDPOINT = 'https://accounts.google.com/o/oauth2/token'
GOOGLE_API_BASE_URL = 'https://www.googleapis.com'


class GoogleDriveCustom(models.Model):
	_name = 'custom.google.drive.configure'
	_description = 'Upload Attachments To Google Drive'

	name = fields.Char(string='Name', required=True)
	google_drive_folderid = fields.Char(string='Drive Folder ID')
	gdrive_refresh_token = fields.Char(string='Google drive Refresh Token', copy=False)
	gdrive_access_token = fields.Char(string='Google Drive Access Token', copy=False)
	is_google_drive_token_generated = fields.Boolean(string='Google drive Token Generated',
													 compute='_compute_is_google_drive_token_generated', copy=False)
	gdrive_client_id = fields.Char(string='Google Drive Client ID', copy=False)
	gdrive_client_secret = fields.Char(string='Google Drive Client Secret', copy=False)
	gdrive_token_validity = fields.Datetime(string='Google Drive Token Validity', copy=False)
	gdrive_redirect_uri = fields.Char(string='Google Drive Redirect URI', compute='_compute_redirect_uri')




	def write(self, vals):
		rec = super(GoogleDriveCustom, self).write(vals)
		all_data = self.env['custom.google.drive.configure'].sudo().search([])
		if len(all_data) > 1:
			raise ValidationError(_("You Cannot Create More Than One Configuration!"))
		return rec


	@api.model
	def create(self, vals):
		rec = super(GoogleDriveCustom, self).create(vals)
		all_data = self.env['custom.google.drive.configure'].sudo().search([])
		if len(all_data) >1:
			raise ValidationError(_("You Cannot Create More Than One Configuration!"))
		return rec

		

	@api.depends('google_drive_folderid')
	def _compute_redirect_uri(self):
		for rec in self:
			base_url = request.env['ir.config_parameter'].get_param('web.base.url')
			rec.gdrive_redirect_uri = base_url + '/google_drive/authentication'

	@api.depends('gdrive_access_token', 'gdrive_refresh_token')
	def _compute_is_google_drive_token_generated(self):
		"""
		Set True if the Google Drive refresh token is generated
		"""
		for rec in self:
			rec.is_google_drive_token_generated = bool(rec.gdrive_access_token) and bool(rec.gdrive_refresh_token)

	def action_get_gdrive_auth_code(self):
		"""
		Generate ogoogle drive authorization code
		"""

		action = self.env["ir.actions.act_window"].sudo().for_xml_id("google_drive_attachment","action_custom_google_configure_data_configure")
		
		base_url = request.env['ir.config_parameter'].get_param('web.base.url')
		url_return = base_url + '/web#id=%d&action=%s&view_type=form&model=%s' % (self.id, action['id'], 'custom.google.drive.configure')
		state = {
			'g_drive_config_id': self.id,
			'url_return': url_return
		}
		encoded_params = urls.url_encode({
			'response_type': 'code',
			'client_id': self.gdrive_client_id,
			'scope': 'https://www.googleapis.com/auth/drive https://www.googleapis.com/auth/drive.file',
			'redirect_uri': base_url + '/google_drive/authentication',
			'access_type': 'offline',
			'state': json.dumps(state),
			'approval_prompt': 'force',
		})
		auth_url = "%s?%s" % (GOOGLE_AUTH_ENDPOINT, encoded_params)
		return {
			'type': 'ir.actions.act_url',
			'target': 'self',
			'url': auth_url,
		}

	def generate_gdrive_refresh_token(self):
		"""
		generate google drive access token from refresh token if expired
		"""
		headers = {"content-type": "application/x-www-form-urlencoded"}
		data = {
			'refresh_token': self.gdrive_refresh_token,
			'client_id': self.gdrive_client_id,
			'client_secret': self.gdrive_client_secret,
			'grant_type': 'refresh_token',
		}
		try:
			res = requests.post(GOOGLE_TOKEN_ENDPOINT, data=data, headers=headers)
			res.raise_for_status()
			response = res.content and res.json() or {}
			if response:
				expires_in = response.get('expires_in')
				self.write({
					'gdrive_access_token': response.get('access_token'),
					'gdrive_token_validity': fields.Datetime.now() + timedelta(seconds=expires_in) if expires_in else False,
				})
		except requests.HTTPError as error:
			error_key = error.response.json().get("error", "nc")

			_logger.info(error_key)
			_logger.info(error_key)
			_logger.info(error)
			_logger.info(error.response)
			_logger.info(error.response.json())

			error_msg = _(
				"An error occurred while generating the token. Your authorization code may be invalid or has already expired [{0}]. "
				"You should check your Client ID and secret on the Google APIs plateform or try to stop and restart your calendar synchronisation.".format(error_key))
			raise UserError(error_msg)

	def get_gdrive_tokens(self, authorize_code):


		print(authorize_code,'authorize_code')
		print(authorize_code,'authorize_code')
		print(authorize_code,'authorize_code')
		print(authorize_code,'authorize_code')


		"""
		Generate G-drive tokens from authorization code
		"""

		base_url = request.env['ir.config_parameter'].get_param('web.base.url')

		headers = {"content-type": "application/x-www-form-urlencoded"}
		data = {
			'code': authorize_code,
			'client_id': self.gdrive_client_id,
			'client_secret': self.gdrive_client_secret,
			'grant_type': 'authorization_code',
			'redirect_uri': base_url + '/google_drive/authentication'
		}
		try:
			res = requests.post(GOOGLE_TOKEN_ENDPOINT, params=data,
								headers=headers)
			res.raise_for_status()
			response = res.content and res.json() or {}
			if response:
				expires_in = response.get('expires_in')
				self.write({
					'gdrive_access_token': response.get('access_token'),
					'gdrive_refresh_token': response.get('refresh_token'),
					'gdrive_token_validity': fields.Datetime.now() + timedelta(
						seconds=expires_in) if expires_in else False,
				})
		except requests.HTTPError:
			error_msg = _("Something went wrong during your token generation. Maybe your Authorization Code is invalid")
			raise UserError(error_msg)