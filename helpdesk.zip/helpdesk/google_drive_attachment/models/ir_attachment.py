# -*- coding: utf-8 -*-
# Part of Laxicon Solution. See LICENSE file for full copyright and
# licensing details.

from odoo import models, fields, api
import json
import requests


class IrAttachment(models.Model):

	_inherit = 'ir.attachment'

	file_id = fields.Char()
	folder_id = fields.Char()



	@api.model
	def get_serving_groups(self):
		return ['base.group_system','base.group_user','base.group_portal']
		

	def create_folder_on_google_drive(self, folder_name, model_obj=None):
		url = 'https://www.googleapis.com/drive/v3/files'
		access_token = self.env['custom.google.drive.configure'].sudo().search([],limit=1).gdrive_access_token

		
		headers = {
			'Authorization': 'Bearer {}'.format(access_token),
			'Content-Type': 'application/json'
		}
		params = self.env['ir.config_parameter'].sudo()
		folder_id = self.env['multi.folder.drive'].sudo().search([('model_id.model', '=', model_obj)], limit=1).folder_id
		parent_id = folder_id
		if not parent_id:
			parent_id = params.get_param('google_drive_attachment.drive_folder_id')
		metadata = {
			'name': folder_name,
			'parents': [parent_id],
			'mimeType': 'application/vnd.google-apps.folder'
		}
		response = requests.post(url, headers=headers, data=json.dumps(metadata))
		if response.status_code == 200:
			des = response.text.encode("utf-8")
			d = json.loads(des)
			return d.get('id')

	@api.model
	def create(self, vals):
		res = super(IrAttachment, self).create(vals)
		model_ids = self.env['ir.config_parameter'].sudo(
		).get_param('google_drive_attachment.model_ids')
		model_ids = [int(x) for x in model_ids.replace(' ','').strip('][').split(',') if x]
		active_model = res.res_model
		m_id = self.env['ir.model'].sudo().search([('model', '=', active_model)])
		m_id = m_id and m_id.id or False
		if model_ids and int(m_id) in model_ids:
			active_id = res.res_id
			folder = self.env['ir.config_parameter'].sudo().get_param('google_drive_attachment.folder_type')
			parent_id = self.env['ir.config_parameter'].sudo().get_param('google_drive_attachment.drive_folder_id')
			if folder == 'single_folder':
				parent_id = parent_id
			if folder == 'multi_folder':
				m_folder_id = self.env['multi.folder.drive'].sudo().search([('model_id.model', '=', active_model)], limit=1)
				parent_id = m_folder_id.folder_id and m_folder_id.folder_id or parent_id
			if folder == 'record_wise_folder':
				rec_id = self.env[active_model].sudo().browse(active_id)
				attachment = self.env['ir.attachment'].sudo().search([('res_model', '=', active_model), ('res_id', '=', active_id), ('folder_id', '!=', False)])
				if not attachment:
					parent_id = self.create_folder_on_google_drive(
						rec_id.name or res.res_name, active_model)
					res.folder_id = parent_id
				else:
					parent_id = attachment.folder_id
			if parent_id:
				try:
					file_url = self.env['google.file.upload'].sudo().upload_to_google_drive(res.name, res.datas, parent_id)
					if file_url:
						res.datas = False
						res.store_fname = ''
						res.db_datas = False
						res.type = 'url'
						res.url = file_url.get('url')
						res.file_id = file_url.get('file_id')
						self.env['ir.attachment'].sudo()._file_gc()
				except:
					pass
		return res

	def unlink(self):
		for rec in self:
			if rec.file_id:
				self.env['google.file.upload'].sudo().delete_from_google_drive(rec.file_id)
			self.env['ir.attachment'].sudo()._file_gc()
		return super(IrAttachment, self).unlink()

	def write(self, vals):


		if vals:

			if vals.get('res_model') != None:

				for res in self:

					model_ids = self.env['ir.config_parameter'].sudo(
					).get_param('google_drive_attachment.model_ids')
					model_ids = [int(x) for x in model_ids.replace(' ','').strip('][').split(',') if x]
					active_model = vals.get('res_model')

					m_id = self.env['ir.model'].sudo().search([('model', '=', active_model)])
					m_id = m_id and m_id.id or False

					if model_ids and int(m_id) in model_ids:
						
						active_id = vals.get('res_id')
						
						folder = self.env['ir.config_parameter'].sudo().get_param('google_drive_attachment.folder_type')
						parent_id = self.env['ir.config_parameter'].sudo().get_param('google_drive_attachment.drive_folder_id')
						
						if folder == 'single_folder':
							parent_id = parent_id
						
						if folder == 'multi_folder':
							
							m_folder_id = self.env['multi.folder.drive'].sudo().search([('model_id.model', '=', active_model)], limit=1)

							parent_id = m_folder_id.folder_id and m_folder_id.folder_id or parent_id
						
						if folder == 'record_wise_folder':
							
							rec_id = self.env[active_model].sudo().browse(active_id)
							attachment = self.env['ir.attachment'].sudo().search([('res_model', '=', active_model), ('res_id', '=', active_id), ('folder_id', '!=', False)])
							if not attachment:
								parent_id = self.create_folder_on_google_drive(
									rec_id.name or res.res_name, active_model)
								res.folder_id = parent_id
							else:
								parent_id = attachment.folder_id
						if parent_id:
							try:
								file_url = self.env['google.file.upload'].sudo().upload_to_google_drive(res.name, res.datas, parent_id)
								if file_url:
									res.datas = False
									res.store_fname = ''
									res.db_datas = False
									res.type = 'url'
									res.url = file_url.get('url')
									res.file_id = file_url.get('file_id')
									self.env['ir.attachment'].sudo()._file_gc()
							except:
								pass


			
		return super(IrAttachment, self).write(vals)