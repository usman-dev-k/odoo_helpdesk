
import json

from odoo import http
from odoo.http import request
import logging
from werkzeug.utils import redirect

_logger = logging.getLogger(__name__)

class GoogleDriveAuthCustom(http.Controller):

   
	@http.route('/google_drive/authentication', type='http', auth="public")
	def gdrive_oauth2callback(self, **kw):
		state = json.loads(kw['state'])

		_logger.info(kw)
		_logger.info(state)
		_logger.info(state)

		backup_config = request.env['custom.google.drive.configure'].sudo().browse(state.get('g_drive_config_id'))
		backup_config.get_gdrive_tokens(kw.get('code'))
		url_return = str(state.get('url_return'))
		return redirect(url_return)