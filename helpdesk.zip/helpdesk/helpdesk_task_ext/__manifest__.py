# -*- coding: utf-8 -*-
{
    'name': "helpdesk_task_ext",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
    """,

    'author': "My Company",
    'website': "http://www.yourcompany.com",

    'category': 'Uncategorized',
    'version': '0.1',

    'depends': ['base','project','helpdesk_mgmt'],

    # always loaded
    'data': [
        'views/views.xml',
        'views/templates.xml',
        'views/email_templates.xml',
    ],
}
