# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import datetime, timedelta, date as date_obj

class helpdesk_task_ext(models.Model):
	_inherit = 'helpdesk.ticket'

	project_task = fields.Many2one('project.task',string="Project Task")

	def helpdesk_task(self):
		if self.name:
			create_task = self.env['project.task'].sudo().create({
				'name':self.name,
				# 'stage_id':self.stage_id,
				'user_id':self.user_id.id,
				'helpdesk_tickect':self.id,
				'project_id':self.team_id.project_tickect.id,
				'description':self.description,
				'user_id':self.user_id.id,
				'tag_ids':self.tag_ids.id,

				})
		self.project_task=create_task

	@api.model
	def create(self, vals):
		new_rec = super(helpdesk_task_ext, self).create(vals)

		new_rec.helpdesk_task()

		return new_rec

	@api.onchange('description')
	def get_the_description(self):
		for x in self:
			if x.description:
				x.project_task.description=x.description

			if x.tag_ids:
				x.project_task.tag_ids=x.tag_ids.id

			if x.name:
				x.project_task.name=x.name




	# def write(self,vals):
	#     new_rec =super(helpdesk_task_ext, self).write(vals)

	#     print("124345")
	#     self.helpdesk_task()
	#     return True


	# def write(self,vals):
	#     print("6666")
	#     print(self)
	#     print("6666")
	#     if 'description' in vals:
	#         for x in self:
	#             x.description=x.project_task.description
	#     new_rec =super(helpdesk_task_ext, self).write(vals)
	#     return True

	@api.onchange('user_id')
	def user_assign(self):
		if self.user_id:
			self.project_task.user_id = self.user_id.id

	@api.onchange('stage_id')
	def get_change_stage(self):
		New = 1
		Assign = 6
		Awaiting = 3
		To_clarify = 9
		To_sign = 10
		In_Progress = 2
		QA = 12
		FAT = 13
		Rework = 14
		UAT = 15
		To_deploy = 16
		To_verify = 18
		Done = 4
		Cancelled = 5
		if self.stage_id.id == 1:
			self.project_task.stage_id = 1
		if self.stage_id.id == 6:
			self.project_task.stage_id = 14
		if self.stage_id.id == 3:
			self.project_task.stage_id = 15
		if self.stage_id.id == 9:
			self.project_task.stage_id = 5
		if self.stage_id.id == 10:
			self.project_task.stage_id = 6
		if self.stage_id.id == 2:
			self.project_task.stage_id = 4
		if self.stage_id.id == 12:
			self.project_task.stage_id = 7
		if self.stage_id.id == 13:
			self.project_task.stage_id = 2
		if self.stage_id.id == 14:
			self.project_task.stage_id = 8
		if self.stage_id.id == 15:
			self.project_task.stage_id = 9
		if self.stage_id.id == 16:
			self.project_task.stage_id = 10
		if self.stage_id.id == 18:
			self.project_task.stage_id = 11
		if self.stage_id.id == 4:
			self.project_task.stage_id = 3
		if self.stage_id.id == 5:
			self.project_task.stage_id = 12
	   

class project_task_ext_team(models.Model):
	_inherit ='helpdesk.ticket.team'

	project_tickect = fields.Many2one('project.project', string="Project")


class project_task_ext(models.Model):
	_inherit ='project.task'

	name = fields.Char(string='Title', tracking=True, required=True, index=True, size=40)
	cancelleing_reason = fields.Text(string="Cancelling Reason")
	description = fields.Html(translate=True,required=True)
	helpdesk_tickect = fields.Many2one('helpdesk.ticket', string="Helpdesk Ticket")
	last_stage_update_date = fields.Date(string="Last Stage Update Date", default=fields.Date.today())
	uat_reminded_date = fields.Date(string="Uat Reminded Date")

	update_to_client = fields.Selection(
		[("normal", "Normal"), ("uat_reminded", "UAT Reminded"),("done_reminded", "Done Reminded")],
		string="Auto Reminder To Client",
		default="normal",
		help="Send Auto Reminder to Client For Tasks, 1st in UAT stage and then 2nd for auto move to done stage after 7 days"
	)

	@api.onchange('user_id')
	def user_assign(self):
		if self.user_id:
			self.helpdesk_tickect.user_id = self.user_id.id
			
	@api.onchange('stage_id')
	def get_change_stage(self):
		New = 1
		Assign = 14
		Awaiting = 15
		To_clarify = 5
		To_sign = 6
		In_Progress = 4
		QA = 7
		FAT = 2
		Rework = 8
		UAT = 9
		To_deploy = 10
		To_verify = 11
		Done = 3
		Cancelled = 12
		if self.stage_id.id == 1:
			self.helpdesk_tickect.stage_id = 1
		if self.stage_id.id == 14:
			self.helpdesk_tickect.stage_id = 6
		if self.stage_id.id == 15:
			self.helpdesk_tickect.stage_id = 3
		if self.stage_id.id == 5:
			self.helpdesk_tickect.stage_id = 9
		if self.stage_id.id == 6:
			self.helpdesk_tickect.stage_id = 10
		if self.stage_id.id == 4:
			self.helpdesk_tickect.stage_id = 2
		if self.stage_id.id == 7:
			self.helpdesk_tickect.stage_id = 12
		if self.stage_id.id == 2:
			self.helpdesk_tickect.stage_id = 13
		if self.stage_id.id == 8:
			self.helpdesk_tickect.stage_id = 14
		if self.stage_id.id == 9:
			self.helpdesk_tickect.stage_id = 15
		if self.stage_id.id == 10:
			self.helpdesk_tickect.stage_id = 16
		if self.stage_id.id == 11:
			self.helpdesk_tickect.stage_id = 18
		if self.stage_id.id == 3:
			self.helpdesk_tickect.stage_id = 4
		if self.stage_id.id == 12:
			self.helpdesk_tickect.stage_id = 5


		if 'cancel' in str(self.stage_id.name).lower():
			if not self.cancelleing_reason:
				raise ValidationError('Please Add Cancelling Reason of Task!')


	@api.onchange('description')
	def get_the_description(self):
		for x in self:
			if x.description:
				x.helpdesk_tickect.description=x.description


	@api.model
	def create(self, vals):
		if 'stage_id' in vals:
			vals['last_stage_update_date'] = fields.Date.today()

		if 'description' not in vals:
			raise ValidationError('Please Add The Description of Task!')
			
		return super(project_task_ext, self).create(vals)

	def write(self, vals):
		if 'stage_id' in vals:
			vals['last_stage_update_date'] = fields.Date.today()
		return super(project_task_ext, self).write(vals)

	@api.onchange('stage_id')
	def _onchange_stage_id(self):
		for x in self:
			x.last_stage_update_date = fields.Date.today()



	@api.model
	def cron_auto_activity_user_task(self):
		today_date = fields.Date.today()
		tasks = self.env["project.task"].sudo().search([('user_id','!=',False),("last_stage_update_date", "<", today_date),('stage_id','not in',[12,3,35]),('project_id','!=',False)])
		for task in tasks:
			if 'internal' not in str(task.project_id.name).lower():
				task_last_update_days = (today_date - task.last_stage_update_date).days
				if task_last_update_days >= 7:
					current_activities = task.activity_ids
					if current_activities:
						current_activities = current_activities.filtered(lambda d: d.activity_type_id.id == 4 and d.date_deadline > fields.Date.today())
					if not current_activities:
						todos = {
							'res_id': task.id,
							'res_model': 'project.task',
							'res_model_id': self.env['ir.model'].search([('model', '=', 'project.task')]).id,
							'user_id': task.user_id.id,
							'summary': 'Action To Do',
							'note': """We'd like to remind you that we have not had a feedback from you regarding this task and stage has not been updated since %s days. Can you please provide us with an answer/update?"""%str(task_last_update_days),
							'activity_type_id': 4,
							'date_deadline': fields.Date.today() + timedelta(days=7)
						}
						activity = self.env['mail.activity'].sudo().create(todos)



	@api.model
	def cron_auto_uat_user_client(self):
		today_date = fields.Date.today()
		tasks = self.env["project.task"].sudo().search([('user_id','!=',False),("update_to_client", "=", 'normal'),('stage_id','in',[9]),('project_id','!=',False)])
		for task in tasks:
			if 'internal' not in str(task.project_id.name).lower():
				if task.project_id.customer_id:
					if task.project_id.customer_id.email:
						reminder_template_id = self.env.ref('helpdesk_task_ext.email_template_send_reminer_client_uat')
						reminder_template_id.send_mail(task.id, notif_layout='mail.mail_notification_light', force_send=True)
						task.write({"update_to_client": 'uat_reminded','uat_reminded_date':fields.Date.today()})





	@api.model
	def cron_auto_done_user_client(self):
		today_date = fields.Date.today()
		tasks = self.env["project.task"].sudo().search([('user_id','!=',False),("update_to_client", "=", 'uat_reminded'),('stage_id','in',[9]),('project_id','!=',False)])
		for task in tasks:
			if 'internal' not in str(task.project_id.name).lower():
				if task.project_id.customer_id:
					if task.project_id.customer_id.email:
						uat_reminded_date_days = (today_date - task.uat_reminded_date).days
						if uat_reminded_date_days >= 7:
							reminder_template_id = self.env.ref('helpdesk_task_ext.email_template_task_moved_to_done')
							reminder_template_id.send_mail(task.id, notif_layout='mail.mail_notification_light', force_send=True)
							task.write({"update_to_client": 'done_reminded','stage_id':3})